#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "question.h"
#include "print.h"
void usage();	

int main(int arc, char* argv[]) {
	int i = 1, choice, select;
	char filename[20], filenamecopy[20], *file, dirqb[100], dirqz[100], dirinfo[100], temp[100], more;
	question_ll* questionsarr;
	StudentInfo studentinfo;
	int id = 0, no;
	char ch;
	QuestionBank qb;/*QuestionBank*/
	QuizSet quizset;/*Quiz + info*/
	if(arc > 1) {/*Checking for options*/
		if(strcmp(argv[1],"-h") == 0) {
			usage();
			return 0;
		}
	}
	initquizset(&quizset);
	Quiz* quiz = &(quizset.quiz);/*only quiz(not info part)*/
	initial();
	choice = getchar();
	if(choice == 27)/*ESC 27*/{
		system("clear");
		exit(0);
	}
	initialization();/*Creates required directory*/
	
	choice = loginprint();
	validation(choice, studentinfo.ID);
	while(1) {
		select = printmenu(choice);
		
		init(&qb);
		strcpy(dirqb, "./QuestionBank/");
		strcpy(dirqz, "./Quiz/");
		strcpy(dirinfo, "./Info/");
		switch(select) {
			case CREATEQB:
				
				init(&qb);
				id = 0;
				do {/**for new question bank*/
					printheader("Quizzy");
					printmiddle("Creation of Question Bank");
					printf("\n");
					printmiddle("     Type of question                Choice of code");
					printf("\n");
					printmiddle("Multiple Choice Question  (MCQ)                [1]");
					printmiddle("Multiple Answer Question  (MAQ)                [2]");
					printmiddle("Numerical Answer Question (NAQ)                [3]");
					printmiddle("Match the pair            (MTP)                [4]");
					printf("\n");
					addQuestion(&qb, &id);
				
					printf("\nDo u want to enter more questions (y | n) :\n");
					scanf("%c", &more);
					getchar();
				}while(more != 'n');
				printheader("Quizzy");
				printf("Your Question Bank :\n");
				readQBstruct(&qb, 0);
				printf("\n(Press ENTER key)\n");
				getchar();
				printf("Save the question bank(Y | N):\n");
				ch = getchar();
				getchar();
				
				if(ch == 'Y') {/*storing*/
					printf("Enter a name for Question Bank:\n");
					scanf("%s", filename);
					getchar();
					strcat(filename, ".qb");
					strcpy(filename, strcat(dirqb, filename));
					storeQB(&qb, filename, 0);
				}

				break;

			case VIEWQB:
				printheader("Quizzy");
				printmiddle("View Question Banks");
				file = getfilename("./QuestionBank/", ".qb");
				if(file) {
					strcpy(temp, dirqb);
					strcat(temp, file); strcat(temp, ".qb");
					printheader("Quizzy");
					printmiddle("View Question Banks");
					printmiddle(temp);
					readQB(temp, 0);/*0 for not reading marks*/
				}
				
				break;
			case CREATEQZ:
				init(quiz);
				printheader("Quizzy");
				printmiddle("Creation of Quiz");
				file = getfilename("./QuestionBank/", ".qb");
				if(file == NULL)
					break;
				strcat(file, ".qb");
				strcpy(file, strcat(dirqb, file));
				readQBQuiz(&quizset, file);/*reads the question bank and stores in quiz*/
				if(quizset.total_marks != 0){
					printheader("Quizzy");
					printf("Your Quiz :\n");
					readQBstruct(quiz, 1);/*show marks*/
					printf("Press ENTER\n");
					getchar();
					printf("Save the question bank(Y | N):\n");
					ch = getchar();
					getchar();
					printf("Enter a name for the quiz :\n");
					scanf("%s", filename);
					strcpy(filenamecopy, filename);
					getchar();
					if(ch == 'Y') {
						strcat(filename, ".quiz");
						strcpy(filename, strcat(dirqz, filename));
						storeQB(quiz, filename, 1);/*Stores the quiz part in the file .quiz*/
						strcat(filenamecopy, ".info");/*Creating .info file*/
						strcpy(filenamecopy, strcat(dirinfo, filenamecopy));
						storeQuizInfo(&quizset, filenamecopy);
					}
				}
				break;
			case VIEWQZ:
				printheader("Quizzy");
				printmiddle("View Quiz Sets");
				file = getfilename("./Quiz/", ".quiz");
				if(file == NULL)
					break;
				printheader("Quizzy");
				printmiddle("View Quiz Sets");
				printmiddle(file);
				readQuizSet(file);
				break;
			case EXPORT:
				printheader("Quizzy");
				printmiddle("Export Window");

				printf("Enter the question bank name to be exported:\n");
				scanf("%s", temp);
				getchar();
				export2(temp);
				break;
			case IMPORT:
				printheader("Quizzy");
				printmiddle("Import Window");

				printf("Enter the xml file name to be imported:\n");
				scanf("%s", temp);
				getchar();
				import(temp);
				break;
			case RUNQZ :
				printheader("Quizzy");
				printmiddle("List of Quiz Set");
				file = getfilename("./Quiz/", ".quiz");
				if(file == NULL)
					break;
				/*Fetching the data from "file"*/
				questionsarr = NULL;
				strcpy(temp, "./Quiz/");
				strcat(temp, file);
				strcat(temp, ".quiz");
				fetchquizinfo(&studentinfo, file);
				questionsarr = fetchquiz(temp/*filename*/ );
				if(questionsarr == NULL)
					printf("Error Null");
				
				printf("PRESS ENTER to start Quiz\n");
				getchar();
				shuffle(questionsarr, studentinfo.totalques);
				if(runquiz(&studentinfo, questionsarr) == NULL) {//termination
					free(questionsarr);
					break;
				}
				free(questionsarr);
				break;
			case PENDINGQZ :
				printheader("Quizzy");
				printmiddle("Pending quiz set");
				no = getNoOfPendingQuiz(studentinfo);
				if(no == -1 || no == 0) {
					printf("\n\nThere are No quiz set pending for you.\nPress ENTER\n");
					getchar();
					break;
				}
				printf("\n\nThere are %d Quiz Set Pending for you\n", no);
				file = selectPendingQuiz(studentinfo, no);
				printf("Filename given by selectPending %s\n", file);
				modifyStudentInfo(&studentinfo, file);
				questionsarr = NULL;
				strcpy(temp, "./Quiz/");
				strcat(temp, file);
				strcat(temp, ".quiz");
				//printf("Temp ==%s\n",temp);
				questionsarr = fetchquiz(temp);
				if(questionsarr == NULL)
					printf("Error Null");
				
				printf("PRESS ENTER to start Quiz\n");
				getchar();
				if(runquiz(&studentinfo, questionsarr) == NULL) {//termination
					free(questionsarr);
					break;
				}
				storeStudentInfo(&studentinfo);
				free(file);
				free(questionsarr);
				break;
				
		}
	}
	return 0;
}
/*Prints usage with the help  of quizzy.help file*/
void usage() {
	FILE* fp;
	char ch;
	fp = fopen("quizzy.help", "r");
	if(fp == NULL) {
		printf("Help file is missing\n");
		return;
	}
	
	while((fread(&ch, sizeof(char), 1, fp)) != 0) {
		printf("%c", ch);
	}
	
	fclose(fp);	
}
