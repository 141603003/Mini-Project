#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <mxml.h>
#include "question.h"
#include "print.h"
void init(QuestionBank* qb) {
	qb->start = NULL;
	qb->curr = NULL;
	qb->no_of_question = 0;
}

void initquizset(QuizSet* qz) {
	qz->total_marks = 0;
	qz->time = 0;
}

void addQuestion(QuestionBank* qb, int* id) {
	int t, no, i = 0, j = 0;
	char temp, ch;
	question_ll* node = (question_ll*)malloc(sizeof(question_ll));
	printf("Q%d.\n", (*id) + 1);
	printf("Enter the choice code for the type of Question:\n");
	scanf("%d", &t);
	(node->q).type_of_ques = t;/*Question type*/
	(node->q).id = ++(*id);/*Question ID*/
	switch(t) {
		case _MCQ:/*MCQ*/
		case _MAQ:
			printf("\nEnter the question text :\n");
			getchar();
			scanf("%[^\n]%*c", (node->q).ques.mcq.qs.ques);/*Reading question*/
			(node->q).ques.mcq.qs.q_length = strlen((node->q).ques.mcq.qs.ques);/*storing length of question*/
			printf("\nHow many options: \n");
			scanf("%d", &no);
			(node->q).ques.mcq.no_of_opt = no;/*No of options*/
			option_ptr opt_ptr;/*option list*/
			opt_ptr.start = NULL;
			printf("\nLabels\n");
			for(i = 0; i < no; i++) {
				printf("%6c : ", (i+1+64));
				addOption(&opt_ptr);			
			}
			(node->q).ques.mcq.opts = opt_ptr.start;/*adding option*/
			getchar();

			/*new question created*/ 
			if(t == _MAQ) {
				(node->q).ques.maq.ans = (char*)malloc(sizeof(char) * no + 1);
				printf("\nCorrect option(label)(separated with ,) : \n");
				j = 0;
				while((ch = getchar()) != '\n' ) {
					if(ch != ',' && ch != ' ' && j < no) {
						(node->q).ques.maq.ans[j] = ch;
						j++;
					}					
				}
				(node->q).ques.maq.ans[j] = '\0';
				
			}
			else {/*for MCQ*/
				printf("\nCorrect option(label) : \n");
				scanf("%c", &((node->q).ques.mcq.ans));/*Answer*/
				getchar();		
			}
				
			break;
		case _NAQ:
			printf("\nEnter the question string:\n");
			getchar();
			scanf("%[^\n]%*c", (node->q).ques.naq.qs.ques);/*Reading question*/
			(node->q).ques.naq.qs.q_length = strlen((node->q).ques.naq.qs.ques);/*storing length of question*/
			printf("\nEnter correct answer :\n");
			scanf("%lf", &((node->q).ques.naq.ans));
			getchar();
			break;
		case _MTP:
			printf("How many pairs:");
			scanf("%d", &no);
			getchar();
			if(no != 0){
				printf("\nNOTE : Enter the option + ENTER followed by corresponding answer\n\n");
			}
			(node->q).ques.mtp.no_of_pairs = no;
			(node->q).ques.mtp.pairs = NULL;
			for(i = 0; i < no; i++) {
				printf("Pair %c :", (i+1+64));
				addPairs(&((node->q).ques.mtp));			
			}
			break;
			
		
				
	}
				
	node->next = NULL;
	/*Adding the new node*/
	if(qb->start == NULL) {/*List empty*/
		qb->start = node;/*Points to sam enode*/	
	}
	else {
		qb->curr->next = node;		
	}
	qb->curr = node;
	qb->no_of_question = *id;	
}
void addPairs(MTP* mtp) {
	char str1[20], str2[20];
	pair* node = malloc(sizeof(pair));
	pair* p;
	scanf("%[^\n]s", str1);
	getchar();
	printf("Answer :");
	scanf("%[^\n]s", str2);
	getchar();
	strcpy(node->str1, str1);
	strcpy(node->str2, str2);
	node->next = NULL;
	pair* start = mtp->pairs;
	if(start == NULL) {/*List empty*/
		start = node;	
	}
	else {
		p = start;
		while((p)->next != NULL) {
			(p) = (p)->next;		
		}
		(p)->next = node;
		
	}
	mtp->pairs = start;
}
void addOption(option_ptr* opt_ptr) {
	option* start = opt_ptr->start;
	char str[20];
	option* p;
	getchar();
	scanf("%[^\n]s", str);/*asking option*/
	option* node = (option*) malloc(sizeof(option));
	strcpy(node->opt_str, str); /*option string*/
	node->opt_length = strlen(node->opt_str);/*length*/
	node->next = NULL;
	if(start == NULL) {/*List empty*/
		start = node;	
	}
	else {
		p = start;
		while((p)->next != NULL) {
			(p) = (p)->next;		
		}
		(p)->next = node;
		
	}
	opt_ptr->start = start;
	
}

void readQBstruct(QuestionBank* qb, int showMarks/*boolean flag*/) {
	MCQ mcq;
	MAQ maq;
	NAQ naq;
	MTP mtp;
	pair* pair;
	questionString qs;
	option* opts;
	question_ll* p = qb->start;
	while(p != NULL) {
		printf("%d: ",(p->q).id);
		switch((p->q).type_of_ques) {
			case _MCQ: printf("MCQ : ");
				mcq = (p->q).ques.mcq;
				qs = mcq.qs;
				printf("%s\n", qs.ques);
				if(!mcq.opts)
					printf("Options are not there");
				opts = mcq.opts;
				
				while(opts != NULL) {
					printf("%s\t", opts->opt_str);
					opts = opts->next;				
				}
				printf("\nCorrect ans: %c\n\n", mcq.ans);
				break;
			case _MAQ:
				printf("MAQ : ");
				maq = (p->q).ques.maq;
				qs = maq.qs;
				printf("%s\n", qs.ques);
				opts = maq.opts;
				if(!opts)
					printf("Options are not there");
				while(opts != NULL) {
					printf("%s\t", opts->opt_str);
					opts = opts->next;				
				}
				printf("\nCorrect ans: %s\n\n", maq.ans);
				break;
			case _NAQ:
				naq = (p->q).ques.naq;
				qs = naq.qs;
				printf("%s\n", qs.ques);
				printf("Correct ans: %lf\n\n", naq.ans);
				break;	
			case _MTP:
				mtp = (p->q).ques.mtp;
				printf("No of pairs: %d\n", mtp.no_of_pairs);
				pair = mtp.pairs;
				
				while(pair != NULL) {
					printf("%-25s\t%-25s\n", pair->str1, pair->str2);
					pair = pair->next;				
				}
				printf("\n");
				break;	
		}
		if(showMarks) {
			printf("%50s......Marks[%d]\n", "", p->marks);		
		}
		p = p->next;
		
	}	
}
void storeQB(QuestionBank* qb, char* file, int storemarks) {/*storemarks indicate*/
	FILE* fp = fopen(file, "w");
	MCQ mcq;
	MAQ maq;
	NAQ naq;
	MTP mtp;
	pair* pairs;
	questionString qs;
	option* opts;
	question_ll* p = qb->start;
	if(!fp) {
		perror("Cant open file ");
		return;
	}
	if(!qb) {
		printf("List was empty");
	}
	fwrite(&(qb->no_of_question), sizeof(int), 1, fp);/*no of ques*/
	while(p != NULL) {
		fwrite(&((p->q).id), sizeof(int), 1, fp);
		fwrite(&((p->q).type_of_ques), sizeof(int), 1, fp);
		switch((p->q).type_of_ques) {
			case _MCQ: 
				mcq = (p->q).ques.mcq;
				qs = mcq.qs;
				fwrite(&qs,sizeof(struct questionString), 1, fp);/*Storing questionString structure*/
				opts = mcq.opts;
			
				fwrite(&(mcq.no_of_opt), sizeof(int), 1, fp);/*no of options*/
				while(opts != NULL) {
					fwrite(&(opts->opt_str), sizeof(char) * 20, 1, fp);/*Storing options*/
					opts = opts->next;				
				}
				fwrite(&mcq.ans, sizeof(char), 1, fp);
				break;
			case _MAQ:
				maq = (p->q).ques.maq;
				qs = maq.qs;
				fwrite(&qs,sizeof(struct questionString), 1, fp);/*Storing questionString structure*/
				opts = maq.opts;
			
				fwrite(&(maq.no_of_opt), sizeof(int), 1, fp);
				while(opts != NULL) {
					fwrite(&(opts->opt_str), sizeof(char) * 20, 1, fp);
					opts = opts->next;				
				}
				fwrite(maq.ans, sizeof(char), strlen(maq.ans) + 1, fp);/*storing string with \0*/
				break;
			case _NAQ:
				naq = (p->q).ques.naq;
				fwrite(&naq, sizeof(NAQ), 1, fp);/*Storing NAQ structure*/
				break;
			case _MTP:
				mtp = (p->q).ques.mtp;
				pairs = mtp.pairs;
			
				fwrite(&(mtp.no_of_pairs), sizeof(int), 1, fp);/*No of pairs*/
				while(pairs != NULL) {
					fwrite(pairs, sizeof(pair), 1, fp);
					pairs = pairs->next;				
				}
				break;
						
		}
		if(storemarks == 1) {
			fwrite(&(p->marks), sizeof(int), 1, fp);
		}
		p = p->next;
	}
	printf("Written successfully to %s\n", file);
	printf("Press ENTER\n");
	getchar();
	fclose(fp);
	
}

void storeQuizInfo(QuizSet* qs, char* file) {
	FILE* fp = fopen(file, "w");
	if(fp == NULL) {
		perror("Cannot create a quizinfo file" );
		return;
	}
	if(qs == NULL)
		return;
	fwrite(&(qs->total_marks), sizeof(int), 1, fp);/*total marks*/
	fwrite(&(qs->time), sizeof(int), 1, fp);/*time*/
	fwrite(&((qs->quiz).no_of_question), sizeof(int), 1, fp);/*no of qs*/
	fclose(fp);
}

/*Reads the data from file as question Bank*/
void readQB(char* file_name, int readmarks) {/*readmarks indicate whether to read marks or not*/
	FILE* fp = fopen(file_name, "r");
	//printf("%s\n", file_name);
	pair* p;
	int i, j, k = 0, marks = 0;
	questionString qs;
	NAQ naq;
	char str[20], ch;
	if(!fp) {
		perror("Cant open file ");
		getchar();
		return;
	}
	
	fread(&i, sizeof(int), 1, fp);/*no of ques*/
	printf("%s contains %d questions\n\n", file_name, i);
	while(fread(&i, sizeof(int), 1, fp) != 0) {/*question ID*/
		printf("Q%d. ", i);
		fread(&i, sizeof(int), 1, fp);/*ques type*/
		switch(i) {
			case _MCQ: 
				fread(&qs,sizeof(struct questionString), 1, fp);/*Storing questionString structure*/
				printf("%s\n", qs.ques);
				fread(&i, sizeof(int), 1, fp);/*no of options*/
				j = 0;
				while(j < i) {

					fread(&str, sizeof(char) , 20, fp);/*Reading options*/
					printf("%c. %s\t", (j + 1 + 64), str);	
					j++;
							
				}
				fread(&ch, sizeof(char), 1, fp);
				
				break;
			case _MAQ:
				fread(&qs,sizeof(struct questionString), 1, fp);/*Storing questionString structure*/
			
				printf("%s\n", qs.ques);
				
				fread(&k, sizeof(int), 1, fp);/*no of options*/
				j = 0;
				while(j < k) {

					fread(&str, sizeof(char) , 20, fp);/*Reading options*/
					printf("%c. %s\t", (j + 1 + 64), str);	
					j++;
							
				}
				j = 0;
				do {
					fread(&ch, sizeof(char), 1, fp);/*reading ans till '\0'*/
					str[j] = ch;
					j++;
				}while(ch != '\0');
				/*printf("\n%s\n", str);	*/			
				break;
			case _NAQ:
				fread(&naq, sizeof(NAQ), 1, fp);
				qs = naq.qs;
				printf("%s \n", qs.ques);
				break;	
			case _MTP:
				fread(&i, sizeof(int), 1,fp);
				printf("Match the following pairs:\n");
				p = (pair*)malloc(sizeof(pair));
				if(p == NULL) printf("Memory not allocated");
				for(j = 0; j < i; j++) {
					printf("%c:", (j+1+64));
					fread(p, sizeof(pair), 1, fp);
					printf("%s\t%s\n", p->str1, p->str2);			
				}
				free(p);
				break;	
		}
		if(readmarks == 1){
			fread(&marks, sizeof(int), 1, fp);
			printf("\n%50s......Marks[%d]\n", "",marks);
		}
		printf("\n\n");
	}
	printf("Press ENTER\n");
	getchar();
	fclose(fp);
}

void addOptionQuiz(option_ptr* opt_ptr, char* str) {
	option* start = opt_ptr->start;
	option* p;
	option* node = (option*) malloc(sizeof(option));
	strcpy(node->opt_str, str); /*option string*/
	node->opt_length = strlen(node->opt_str);/*length*/
	node->next = NULL;
	if(start == NULL) {/*List empty*/
		start = node;	
	}
	else {
		p = start;
		while((p)->next != NULL) {
			(p) = (p)->next;		
		}
		(p)->next = node;
		
	}
	opt_ptr->start = start;
	
}

void addPairsQuiz(MTP* mtp, pair* p) {
	pair* node = malloc(sizeof(pair));
	strcpy(node->str1, p->str1);
	strcpy(node->str2, p->str2);
	node->next = NULL;
	pair* start = mtp->pairs;
	if(start == NULL) {/*List empty*/
		start = node;	
	}
	else {
		p = start;
		while((p)->next != NULL) {
			(p) = (p)->next;		
		}
		(p)->next = node;
		
	}
	mtp->pairs = start;
}
void readQBQuiz(QuizSet* quizset, char* file_name) {
	FILE* fp = fopen(file_name, "r");
	pair* p;
	Quiz* quiz = &(quizset->quiz);
	int i, j, k = 0, countq = 0/*Question counter*/, marks, totalmarks = 0;
	questionString qs;
	option_ptr opt_ptr;
	NAQ naq;
	char str[20], ch, select;
	if(!fp) {
		perror("Cant open file ");
		return;
	}
	fread(&i, sizeof(int), 1, fp);/*no of ques*/
	printf("%s contains %d questions\n\n", file_name, i);
	printf("Press ENTER\n");
	getchar();
	while(fread(&i, sizeof(int), 1, fp)) {/*question ID*/
		printheader("Quizzy");
		printmiddle("Creation of Quiz");
		printmiddle(file_name);
		printf("Q%d. ",i);
		question_ll* node = (question_ll*)malloc(sizeof(question_ll));
		(node->q).id = (countq + 1);/*Question ID*/
		fread(&i, sizeof(int), 1, fp);/*ques type*/
		(node->q).type_of_ques = i;/*Question type*/
		switch(i) {
			case _MCQ: 
				fread(&qs,sizeof(struct questionString), 1, fp);/*Reading questionString structure*/
				printf("%s\n", qs.ques);
				(node->q).ques.mcq.qs = qs;
				fread(&i, sizeof(int), 1, fp);/*no of options*/
				(node->q).ques.mcq.no_of_opt = i;/*No of options*/
				/*option list*/
				opt_ptr.start = NULL;
				j = 0;
				while(j < i) {

					fread(&str, sizeof(char) , 20, fp);/*Reading options*/
					printf("%c. %s\t", (j + 1 + 64), str);	
					addOptionQuiz(&opt_ptr, str);
					j++;
							
				}
				(node->q).ques.mcq.opts = opt_ptr.start;/*adding option*/
				fread(&ch, sizeof(char), 1, fp);
				(node->q).ques.mcq.ans = ch;/*Answer*/
				break;
			case _MAQ:
				fread(&qs,sizeof(struct questionString), 1, fp);/*Reading questionString structure*/
				printf("%s\n", qs.ques);
				(node->q).ques.mcq.qs = qs;
				fread(&i, sizeof(int), 1, fp);/*no of options*/
				(node->q).ques.mcq.no_of_opt = i;/*No of options*/
				option_ptr opt_ptr;/*option list*/
				opt_ptr.start = NULL;
				j = 0;
				while(j < i) {

					fread(&str, sizeof(char) , 20, fp);/*Reading options*/
					printf("%c. %s\t", (j + 1 + 64), str);	
					addOptionQuiz(&opt_ptr, str);
					j++;
							
				}
				(node->q).ques.mcq.opts = opt_ptr.start;/*adding option*/
				j = 0;
				do {
					fread(&ch, sizeof(char), 1, fp);/*reading ans till '\0'*/
					str[j] = ch;
					j++;
				}while(ch != '\0');
				(node->q).ques.maq.ans = (char*)malloc(sizeof(char) * i + 1);/*i contains number of options*/
				strcpy((node->q).ques.maq.ans, str);			
				break;
			case _NAQ:
				fread(&naq, sizeof(NAQ), 1, fp);
				qs = naq.qs;
				printf("%s (%d)\n", qs.ques, qs.q_length);
				(node->q).ques.naq = naq;
				break;	
			case _MTP:
				fread(&i, sizeof(int), 1,fp);/*no of pairs*/
				(node->q).ques.mtp.no_of_pairs = i;
				(node->q).ques.mtp.pairs = NULL;
				printf("Match the following pairs:\n");
				p = (pair*)malloc(sizeof(pair));
				//if(p == NULL) printf("Memory allocated");
				for(j = 0; j < i; j++) {
					printf("%c:", (j+1+64));
					fread(p, sizeof(pair), 1, fp);
					printf("%s\t%s\n", p->str1, p->str2);
					addPairsQuiz(&((node->q).ques.mtp), p); /*Adding pairs*/
								
				}
				break;	
		}
		printf("\n\n");
		printf("Select above question: (y|n) \n");
		scanf("%c", &select);
		getchar();
		if(select == 'y') {
			printf("Allocate Marks:\n");
			scanf("%d", &marks);
			totalmarks = totalmarks + marks;
			getchar();
			(node->marks) = marks;
			node->next = NULL;
			/*Adding the new node*/
			if(quiz->start == NULL) {/*List empty*/
				quiz->start = node;/*Points to sam enode*/	
			}
			else {
				quiz->curr->next = node;		
			}
			quiz->curr = node;
			quiz->no_of_question = (++countq);
		}
		else {/*Node not needed*/
			free(node);
		
		}
	}
	quizset->total_marks = totalmarks;
	if(totalmarks) {
		printf("\nAllocate Max Time for this quiz:\n(minutes)");
		scanf("%d", &(quizset->time));
		printf("\nPress ENTER\n");
		getchar();
	}
	getchar();
	fclose(fp);
}

void readquizinfo(char* file) {
	FILE* fp = fopen(file, "r");
	int y;
	if(!fp) {
		perror("Cant open file ");
		getchar();
		return;
	}
	printf("\nInformation of Quiz Set:\n");
	printf("\t%-15s %10s...", "Total Marks","");
	fread(&y, sizeof(int), 1, fp);
	printf("%d\n", y);
	printf("\t%-15s %10s...", "Time Allocated", "");
	
	fread(&y, sizeof(int), 1, fp);
	printf("%d min\n", y);
	printf("\t%-15s %10s...", "No. of questions", "");
	fread(&y, sizeof(int), 1, fp);
	printf("%d min\n\n", y);
}
void readQuizSet(char* file) {
	char quizfile[100], infofile[100], *temp;
	temp = (char*)malloc(sizeof(char) * (strlen(file) + 1));
	strcpy(temp, file);
	strcpy(quizfile, "Quiz Set name : ");
	strcat(quizfile, file);
	printmiddle(quizfile);
	strcpy(quizfile, "./Quiz/");
	strcat(quizfile, strcat(file, ".quiz"));
	strcpy(infofile, "./Info/");
	strcat(infofile, strcat(temp, ".info"));
	
	readquizinfo(infofile);
	readQB(quizfile, 1);/*1 to indicate to read marks also*/
}
/*Fetches only question from quizset*/
question_ll* fetchquiz( char* filename){
	int no_of_ques, i, id, type, temp, j;
	option_ptr opt_ptr;
	questionString qs;
	question_ll* questionarr;
	pair* p;
	NAQ naq;
	char str[20], ans;
	FILE* fp = fopen(filename, "r");
	if(!fp) {
		perror("Cant open file ");
		return NULL;
	}
	fread(&no_of_ques, sizeof(int), 1, fp);/*no of ques*/
	questionarr = NULL;
	questionarr = (question_ll*)malloc(sizeof(question_ll) * no_of_ques);/*Array created here*/
	for(i = 0; i < no_of_ques; i++) {
		fread(&id, sizeof(int), 1, fp);
		questionarr[i].q.id = id;/*ID*/
		fread(&type, sizeof(int), 1, fp);/*ques type*/
		questionarr[i].q.type_of_ques = type;/*Question type*/
		switch(type) {
			case _MCQ: 
				fread(&qs,sizeof(struct questionString), 1, fp);/*Reading questionString structure*/
				questionarr[i].q.ques.mcq.qs = qs;
				fread(&temp, sizeof(int), 1, fp);/*no of options*/
				questionarr[i].q.ques.mcq.no_of_opt = temp;/*No of options*/
				/*option list*/
				opt_ptr.start = NULL;
				j = 0;
				while(j < temp) {

					fread(&str, sizeof(char) , 20, fp);/*Reading options*/	
					addOptionQuiz(&opt_ptr, str);
					j++;
							
				}
				questionarr[i].q.ques.mcq.opts = opt_ptr.start;/*adding option*/
				fread(&ans, sizeof(char), 1, fp);
				questionarr[i].q.ques.mcq.ans = ans;/*Answer*/
				break;
			case _MAQ:
				fread(&qs,sizeof(struct questionString), 1, fp);/*Reading questionString structure*/
				questionarr[i].q.ques.maq.qs = qs;
				fread(&temp, sizeof(int), 1, fp);/*no of options*/
				questionarr[i].q.ques.maq.no_of_opt = temp;/*No of options*/
				/*option list*/
				opt_ptr.start = NULL;
				j = 0;
				while(j < temp) {

					fread(&str, sizeof(char) , 20, fp);/*Reading options*/	
					addOptionQuiz(&opt_ptr, str);
					j++;
							
				}
				questionarr[i].q.ques.maq.opts = opt_ptr.start;/*adding option*/
				j = 0;
				do {
					fread(&ans, sizeof(char), 1, fp);/*reading ans till '\0'*/
					str[j] = ans;
					j++;
				}while(ans != '\0');
				questionarr[i].q.ques.maq.ans = (char*)malloc(sizeof(char) * i + 1);/*i contains number of options*/
				strcpy(questionarr[i].q.ques.maq.ans, str);			
				break;
			case _NAQ:
				fread(&naq, sizeof(NAQ), 1, fp);
				questionarr[i].q.ques.naq = naq;
				break;	
			case _MTP:
				fread(&temp, sizeof(int), 1,fp);/*no of pairs*/
				questionarr[i].q.ques.mtp.no_of_pairs = temp;
				questionarr[i].q.ques.mtp.pairs = NULL;
				p = (pair*)malloc(sizeof(pair));
				//if(p == NULL) printf("Memory allocated");
				for(j = 0; j < temp; j++) {
					fread(p, sizeof(pair), 1, fp);
					addPairsQuiz(&(questionarr[i].q.ques.mtp), p); /*Adding pairs*/
								
				}
				break;	
		}
		fread(&temp, sizeof(int), 1, fp);
		questionarr[i].marks = temp;
		questionarr[i].next = NULL;	
	}
	return questionarr;
}

void fetchquizinfo(StudentInfo* si, char* file){
	char str[100];
	int temp;
	FILE* fp;
	fp = NULL;
	strcpy(str, "./Info/");
	strcat(str, file);
	strcat(str, ".info");
	
	fp = fopen(str, "r");
        if(!fp) {
		perror("Cannot open quiz info file");
		return;
   	}
	
	fread(&temp, sizeof(int), 1, fp);
	si->total_marks = temp;
	fread(&temp, sizeof(int), 1, fp);
	si->totaltime = temp;
	fread(&temp, sizeof(int), 1, fp);
	si->totalques = si-> no_of_ques_left = temp;
	strcpy(si->quizname, file);
	si->score = 0;
	
	
}

char* runquiz(StudentInfo* studentinfo, question_ll* ques) {/*if terminated returns NULL*/
	int n = studentinfo->no_of_ques_left;
	int i = 0, j, no_of_opts, anslen, found, k, left, right;
	char ans, ch, *str, temp[50], con[2];
	double naqans;
	MCQ mcq;
	MAQ maq;
	NAQ naq;
	MTP mtp;
	pair  *pairs, *pairsarr, *pairsarr2;
	
	option* opts;
	questionString qs;
	for(i = 0; i < n; i++) {
		printheader("Quizzy");
		printmiddle(studentinfo->quizname);
		printf("\n");
		printf("%d: ", ques[i].q.id);
		switch(ques[i].q.type_of_ques) {
			case _MCQ: 
				mcq = ques[i].q.ques.mcq;
				qs = mcq.qs;
				printf("%s\n\n", qs.ques);
				if(!mcq.opts)
					printf("Options are not there");
				opts = mcq.opts;
				printf("\n");
				j = 0;
				while(opts != NULL) {
					printf("  %c.%s\n", (char)(j + 'A'), opts->opt_str);
					j++;
					opts = opts->next;				
				}
				
				printf("\n\nEnter the label:\n");
				scanf("%s", temp);
				getchar();
				str = checkforterminate(temp);
				if(str == NULL) {//termination
					terminateQuiz(studentinfo, ques, i);
					return NULL;
				}
				ans = str[0];
				if(ans == mcq.ans)
					studentinfo->score += ques[i].marks;
				(studentinfo->no_of_ques_left)--;
				free(str);
		
				//printf("\nCorrect ans: %c\n\n", mcq.ans);
				break;
			case _MAQ:
				printf("MAQ : ");
				maq = ques[i].q.ques.maq;
				qs = maq.qs;
				printf("%s\n", qs.ques);
				opts = maq.opts;
				no_of_opts = maq.no_of_opt;
				if(!opts)
					printf("Options are not there");
				j = 0;
				while(opts != NULL) {
					printf("%c.%s\n", (char)(j + 'A'), opts->opt_str);
					j++;
					opts = opts->next;				
				}

				printf("\n\n Enter the labels:\n");
				scanf("%[^\n]s", temp);
				printf("Got the labels");
				getchar();
				printf("after getchar\n");
				str = checkforterminate(temp);
				if(str == NULL) {//termination
					terminateQuiz(studentinfo, ques, i);
					return NULL;
				}
				j = 0;
				anslen = strlen(maq.ans);
				while(j < strlen(str)) {/*reading ans*/
					if(str[j] != ',' && str[j] != ' ' && j < no_of_opts) {
						found = 0;
						for(k = 0; k< anslen; k++)
						{
							if(maq.ans[k] == str[j]) {
								studentinfo->score += ((float)ques[i].marks / anslen) ;
								found =1;
								printf("in the loop\n");
								break;
							}
							
						}
						if(!found)
							if(no_of_opts != anslen)
							  	studentinfo->score -= (ques[i].marks / (float)(no_of_opts - anslen)); 
						
					}
					j++;					
				}
				(studentinfo->no_of_ques_left)--;
				free(str);
				//printf("\nCorrect ans: %s\n\n", maq.ans);
				break;
			case _NAQ:
				naq = ques[i].q.ques.naq;
				qs = naq.qs;
				printf("%s\n", qs.ques);
				printf("\n\nEnter the answer (numerical part) :\n");
				scanf("%s", temp);
				getchar();
				str = checkforterminate(temp);
				if(str == NULL) {//termination
					terminateQuiz(studentinfo, ques, i);
					return NULL;
				}
				naqans = (double) atof(str);
				if(naqans == naq.ans)
					studentinfo->score += (float)ques[i].marks;
				(studentinfo->no_of_ques_left)--;
				free(str);
				//printf("Correct ans: %lf\n\n", naq.ans);
				break;	
			case _MTP:
				mtp = ques[i].q.ques.mtp;
				//printf("No of pairs: %d\n", mtp.no_of_pairs);
				pairsarr = (pair*)malloc(sizeof(pair) * mtp.no_of_pairs);
				pairsarr2 = (pair*)malloc(sizeof(pair) * mtp.no_of_pairs);
				pairs = mtp.pairs;
				printf("Match the following:\n");
				j = 0;
				while(pairs != NULL) {/*Copying into arrays*/
					//printf("%c.%-25s\t%d.%-25s\n", (char)(j + 'A'), pairs->str1, (j + 1), pairs->str2);
					pairsarr[j] = *pairs;/*Correct pairs*/
					pairsarr2[j] = *pairs;
					pairs = pairs->next;
					j++;				
				}
				shufflepairs(pairsarr2, mtp.no_of_pairs);/*shuffle the second array*/
				j =0;
				while(j < mtp.no_of_pairs) {
					printf("%d.%-25s\t%c.%-25s\n", (char)(j + 1), pairsarr2[j].str1, (j + 'A'), pairsarr2[j].str2);
					j++;
				}
				printf("\n\nEnter the pairs separated with commas:(ex: 1 - A, 2 - C)\n");
				scanf("%[^\n]s", temp);
				getchar();
				str = checkforterminate(temp);
				if(str == NULL) {//termination
					terminateQuiz(studentinfo, ques, i);
					return NULL;
				}
				/////To read pairs////
				j = 0;
				while(j < strlen(str)) {
					if(isalpha(str[j]) ||isdigit(str[j])) {
						printf("%c is alpha or digit\n", str[j]);
						con[0] = str[j];
						con[1] = '\0';
						left = atoi(con) - 1;
						j++;
						for(; j < strlen(str); j++){
							if(isalpha(str[j]) || isdigit(str[j])){
								if(str[j] == '0'){//no ans given
									break;//dont consider marks
								}
								if(isalpha(str[j])){
									str[j] = toupper(str[j]);
									right = str[j] - 'A';
									if(!strcmp(pairsarr[left].str2, pairsarr2[right].str2)) {
										studentinfo->score += ((float)ques[i].marks / mtp.no_of_pairs);
										printf("Correct\n");
										break;
									}	
								}
							}
						}
					}
					j++;
				}
				free(str);
				(studentinfo->no_of_ques_left)--;
				break;	
		}
		
	}
	(studentinfo->finished) = 1;/*Quiz finished*/
	printf("\nTotal score: %.2f /(out of) %.2f\n", studentinfo->score, (float)studentinfo->total_marks);
	getchar();
	return "ab";
}

void terminateQuiz(StudentInfo* studentinfo, question_ll* ques, int j) {
	(studentinfo->finished) = 0;
	char* filename = storeStudentInfo(studentinfo);
	if(filename != NULL) {
		storeLeftQuestions(ques, filename , j, studentinfo->totalques);
		printf("\nQuiz Suspended...................\n(Press ENTER)\n");
		getchar();
	}
}

char* storeStudentInfo(StudentInfo* studentinfo) {
	FILE *fp;
	StudentInfo temp;
	char file[100], storefile[100];
	int i = 0, j = 0;
	strcpy(file, "./Quiz/");
	strcat(file, studentinfo->ID);
	strcat(file, ".state");//file name ready
	sprintf(storefile, "%ld", random());
	strcat(storefile, ".left.ques");
	//printf("Store file by info %s\n", storefile);
	strcpy(studentinfo->filename, storefile);//left question file
	fp = fopen(file, "r+w");
	if(!fp){
		perror("Cannot create state file");
		getchar();
		return NULL;
  	}
	while((fread(&temp, sizeof(StudentInfo), 1, fp))) {/*Counting the position of structure*/
		if(!strcmp(temp.quizname, studentinfo->quizname)) {
			break;
		}
		i++;
	}
	fseek(fp, 0, SEEK_SET);
	for(j = 0; j < i ; j++)  {/*Move till that position*/
		fread(&temp, sizeof(StudentInfo), 1, fp);
	}
	fwrite(studentinfo, sizeof(StudentInfo), 1, fp);
	fclose(fp);
	return studentinfo->filename;
}
/*Stores left question from curr to end*/
void storeLeftQuestions(question_ll* ques, char* filename, int curr, int end){
	char file[100];
	int j;
	MCQ mcq;
	MAQ maq;
	NAQ naq;
	MTP mtp;
	pair* pairs;
	questionString qs;
	option* opts;
	int no_of_ques = end - curr;
	strcpy(file, "./Quiz/");
	strcat(file, filename);//filename ready
	FILE* fp = fopen(file, "w");//opening file
	//printf("Storing in the file : %s\n", file);
	if(!fp){
		perror("Cannot create left question file");
		getchar();
		return;
  	}
	fwrite(&no_of_ques, sizeof(int), 1, fp);/*no of ques*/
	//printf("value of curr %d\n and of end %d\nNo of questions %d\n", curr, end,no_of_ques);
	//getchar();
	j = curr;
	while(j < end) {
		fwrite(&(ques[j].q.id), sizeof(int), 1, fp);
		fwrite(&(ques[j].q.type_of_ques), sizeof(int), 1, fp);
		switch(ques[j].q.type_of_ques) {
			case _MCQ: 
				mcq = ques[j].q.ques.mcq;
				qs = mcq.qs;
				fwrite(&qs,sizeof(struct questionString), 1, fp);/*Storing questionString structure*/
				//printf("%s\n", qs.ques);
				getchar();
				opts = mcq.opts;
			
				fwrite(&(mcq.no_of_opt), sizeof(int), 1, fp);/*no of options*/
				while(opts != NULL) {
					fwrite(&(opts->opt_str), sizeof(char) * 20, 1, fp);/*Storing options*/
					opts = opts->next;				
				}
				fwrite(&mcq.ans, sizeof(char), 1, fp);
				break;
			case _MAQ:
				maq = ques[j].q.ques.maq;
				qs = maq.qs;
				fwrite(&qs,sizeof(struct questionString), 1, fp);/*Storing questionString structure*/
				//printf("%s\n", qs.ques);
				getchar();
				opts = maq.opts;
			
				fwrite(&(maq.no_of_opt), sizeof(int), 1, fp);
				while(opts != NULL) {
					fwrite(&(opts->opt_str), sizeof(char) * 20, 1, fp);
					opts = opts->next;				
				}
				fwrite(maq.ans, sizeof(char), strlen(maq.ans) + 1, fp);/*storing string with \0*/
				break;
			case _NAQ:
				naq = ques[j].q.ques.naq;
				fwrite(&naq, sizeof(NAQ), 1, fp);/*Storing NAQ structure*/
				break;
			case _MTP:
				mtp = ques[j].q.ques.mtp;
				pairs = mtp.pairs;
			
				fwrite(&(mtp.no_of_pairs), sizeof(int), 1, fp);/*No of pairs*/
				while(pairs != NULL) {
					fwrite(pairs, sizeof(pair), 1, fp);
					pairs = pairs->next;				
				}
				break;
						
		}
		
		fwrite(&(ques[j].marks), sizeof(int), 1, fp);
		//printf("Value of j  %d", j);
		//getchar();
		j++;
	}
	//printf("Wrote left questions to file successfully........\n");
	fclose(fp);
}

int getNoOfPendingQuiz(StudentInfo si){
	FILE *fp;
	StudentInfo stud;
	char temp[100];
	int counter = 0;
	strcpy(temp, "./Quiz/");
	strcat(temp, si.ID);
	strcat(temp, ".state");
	//printf("Reading from %s\n", temp);
	fp = fopen(temp, "r");
	if(!fp)
		return -1;

	while((fread(&stud, sizeof(StudentInfo), 1, fp))) {
		printf("finished value  %d", stud.finished);
		if(stud.finished == 0) {
			counter++;
			//printf("Counter %d",counter);
		} 
	}
	fclose(fp);
	return counter;
}

char* selectPendingQuiz(StudentInfo si, int no) {/*Give names user selected file*/
	FILE *fp;
	char** array;
	StudentInfo stud;
	char temp[100], *ans;
	int counter = 0, i;
	strcpy(temp, "./Quiz/");
	strcat(temp, si.ID);
	strcat(temp, ".state");
	array = (char**) malloc(sizeof(char*) * no);
	for(i = 0; i < no; i++){
		array[i] = (char*) malloc(sizeof(char) * 20);
	}
	//printf("Reading from %s\n", temp);
	fp = fopen(temp, "r");
	printf("\n\n");
	if(!fp)
		return NULL;

	while((fread(&stud, sizeof(StudentInfo), 1, fp))) {
		if(stud.finished == 0) {
			counter++;
			strcpy(array[counter - 1], stud.quizname);
			printf("%d.%s\n", counter, stud.quizname);
			
		} 
	}
	fclose(fp);
	do{
		printf("\nEnter your choice from above quiz set:\n");
		scanf("%d", &i);
		getchar();
		if(i > counter || i < 1)
			printf("Invalid serial number\n");
	}while(i > counter || i < 1);
	i = i - 1;
    	ans = (char*)malloc(sizeof(char) * (strlen(array[i]) + 1));
	strcpy(ans, array[i]);
	for(i = 0; i < no; i++){
		if(array[i]!= NULL)
			free(array[i]);
	}
	if(array != NULL)
			free(array);
	return ans;

}

void modifyStudentInfo(StudentInfo* si, char* file){
	FILE *fp;
	StudentInfo stud;
	char temp[100];

	strcpy(temp, "./Quiz/");
	strcat(temp, si->ID);
	strcat(temp, ".state");
	//printf("Reading from %s\n", temp);
	fp = fopen(temp, "r");
	if(!fp)
		return;
	while((fread(&stud, sizeof(StudentInfo), 1, fp))) {
		if(stud.finished == 0 && !strcmp(stud.quizname, file)) {
			si->finished = stud.finished;//DATA copying
			si->score = stud.score;
			si->no_of_ques_left = stud.no_of_ques_left;
			si->totalques = stud.totalques;
			si->totaltime = stud.totaltime;
			si->total_marks = stud.total_marks;
			strcpy(si->ID , stud.ID);
			strcpy(si->quizname , stud.quizname);
			strcpy(si->filename , stud.filename);
			//printf("Student info modified successfully....\n");
			return;
		} 
	}
	fclose(fp);

}

void export(char* filename) {
	char temp[100], idstr[5];
	pair* p;
	int i, j, k = 0, mark = 0;
	questionString qs;
	NAQ naq;
	char str[20], ch;
	FILE* fp;
	mxml_node_t *xml, *questionbank, *no_of_ques, *value, *question, *marks, *type, *questiontext, *text, *no_of_options, *option, *answer, *id, *no_of_pairs, *pairN, *ques, *ans;
	strcpy(temp, "./QuestionBank/");/*./QuestionBank/filename.qb*/
	strcat(temp, filename);
	strcat(temp, ".qb");
	fp = fopen(temp, "r");
	//printf("%s\n", file_name);
	
	if(!fp) {
		perror("Cant open file ");
		getchar();
		return;
	}
	xml = mxmlNewXML("1.0");//Xml tag
	questionbank = mxmlNewElement(xml, "questionbank");/*questionbank*/
	mxmlElementSetAttr(questionbank, "name", filename);/*name attr*/
	fread(&i, sizeof(int), 1, fp);/*no of ques*/
	no_of_ques = mxmlNewElement(questionbank, "no_of_ques");
	value = mxmlNewInteger(no_of_ques, i);/*no of ques*/
	
	while(fread(&i, sizeof(int), 1, fp) != 0) {/*question ID*/
		question = mxmlNewElement(questionbank,"question");/*question tag*/
		sprintf(idstr, "%d", i);
		mxmlElementSetAttr(question, "id", idstr);
		fread(&i, sizeof(int), 1, fp);/*ques type*/
		type = mxmlNewElement(question, "type");
		value = mxmlNewInteger(type, i);
		switch(i) {
			case _MCQ: 
				fread(&qs,sizeof(struct questionString), 1, fp);/*Storing questionString structure*/
				questiontext = mxmlNewElement(question, "questiontext");
				text = mxmlNewElement(questiontext, "text");
				value = mxmlNewText(text, 0, qs.ques);
				fread(&i, sizeof(int), 1, fp);/*no of options*/
				no_of_options = mxmlNewElement(question, "no_of_options");
				value = mxmlNewInteger(no_of_options, i);
				j = 0;
				while(j < i) {

					fread(&str, sizeof(char) , 20, fp);/*Reading options*/
					option = mxmlNewElement(question, "option");
					sprintf(idstr, "%c", (char)(j + 1 + 64));
					mxmlElementSetAttr(option, "id", idstr);
					text = mxmlNewElement(option, "text");
					value = mxmlNewText(text, 0, str);
					
					j++;
							
				}
				fread(&ch, sizeof(char), 1, fp);
				answer = mxmlNewElement(question, "answer");
				sprintf(idstr, "%c", ch);
				value = mxmlNewText(answer, 0, idstr);
				break;
			case _MAQ:
				fread(&qs,sizeof(struct questionString), 1, fp);/*Storing questionString structure*/
				questiontext = mxmlNewElement(question, "questiontext");
				text = mxmlNewElement(questiontext, "text");
				value = mxmlNewText(text, 0, qs.ques);
				fread(&i, sizeof(int), 1, fp);/*no of options*/
				no_of_options = mxmlNewElement(question, "no_of_options");
				value = mxmlNewInteger(no_of_options, i);
				j = 0;
				while(j < i) {

					fread(&str, sizeof(char) , 20, fp);/*Reading options*/
					option = mxmlNewElement(question, "option");
					sprintf(idstr, "%c", (char)(j + 1 + 64));
					mxmlElementSetAttr(option, "id", idstr);
					text = mxmlNewElement(option, "text");
					value = mxmlNewText(text, 0, str);
					
					j++;
							
				}
				j = 0;
				do {
					fread(&ch, sizeof(char), 1, fp);/*reading ans till '\0'*/
					str[j] = ch;
					j++;
				}while(ch != '\0');
				answer = mxmlNewElement(question, "answer");
		
				value = mxmlNewText(answer, 0, str);			
				break;
			case _NAQ:
				fread(&naq, sizeof(NAQ), 1, fp);
				qs = naq.qs;
				questiontext = mxmlNewElement(question, "questiontext");
				text = mxmlNewElement(questiontext, "text");
				value = mxmlNewText(text, 0, qs.ques);
				answer = mxmlNewElement(question, "answer");
				value = mxmlNewReal(answer, naq.ans);
				break;	
			case _MTP:
				fread(&i, sizeof(int), 1,fp);
				no_of_pairs = mxmlNewElement(question, "no_of_pairs");
				value = mxmlNewInteger(no_of_pairs, i);
				p = (pair*) malloc(sizeof(pair));

				if(p == NULL) {printf("Memory not allocated");}
				for(j = 0; j < i; j++) {
					fread(p, sizeof(pair), 1, fp);
					pairN = mxmlNewElement(question, "pair");
					sprintf(idstr, "%c", (char)(j + 1 + 64));
					mxmlElementSetAttr(pairN, "id", idstr);
					ques = mxmlNewElement(pairN, "ques");
					value = mxmlNewText(ques, 0, p->str1);
					ans = mxmlNewElement(pairN, "ans");
					value = mxmlNewText(ans, 0, p->str2);
								
				}
				free(p);
				break;	
		}
		
		//fread(&mark, sizeof(int), 1, fp);
		marks = mxmlNewElement(question, "marks");
		value = mxmlNewInteger(marks, 0);
		
	}
	fclose(fp);
	printf("Enter a name for xml file:");
	scanf("%s", filename);
	getchar();
	strcpy(temp, "./Export_Files/");/*./QuestionBank/filename.qb*/
	strcat(temp, filename);
	strcat(temp, ".xml");
	fp = fopen(temp, "w");
	if(!fp) {
		perror("Cant open file ");
		getchar();
		return;
	}
	mxmlSaveFile(xml, fp, MXML_NO_CALLBACK);
	printf("\nData exported successfully.........\n");
	fclose(fp);
	mxmlDelete(xml);/*Delete the tree*/
}

void import(char* filename) {/*Assume .xml extension*/
	char temp[100], str[100], idstr[10];
	int i = 0, j = 0, type;
	FILE* fp;
	mxml_node_t *tree;
	mxml_node_t *node, *node2, *node3;
	questionString qs;
	NAQ naq;
	pair pairs;
	 
	if(filename[0] != '/') {
		strcpy(temp, "./");
		strcat(temp, filename);
    	}
	else {
		strcpy(temp, filename);
	}
	fp = fopen(temp, "r");
	if(!fp) {
		perror("Cant open file ");
		getchar();
		return;
	}
	tree = mxmlLoadFile(NULL, fp, MXML_TEXT_CALLBACK);/*Fetching the whole tree*/
	fclose(fp);
	
	if(!tree) {
		errno = EINVAL;
		perror("Not an XML file");
		return;
	}

	//printf("\nEnter a name for this new Question Bank:\n");
	//scanf("%s", filename);
	node = tree->child;//questionbank tag
	strcpy(str, mxmlElementGetAttr(node, "name"));/*name of qb*/
	if(!str) {
		perror("While parsing questionbank tag no name attribute found");
		getchar();
		return;
	}
	strcpy(temp, "./QuestionBank/");
	strcat(temp, str);
	strcat(temp, ".qb");
	fp = fopen(temp , "w");
	if(!fp) {
		perror("Cant open file ");
		getchar();
		return;
	}
	/*Search no_of_ques*/
	node = mxmlFindElement (node, tree, "no_of_ques", NULL, NULL, MXML_DESCEND_FIRST);/*search just 1 level inside*/
	if(!node) {
		perror("While parsing  no <no_of_ques> tag found");
		getchar();
		return;
	}
	fwrite(&(node->child->value.integer), sizeof(int), 1, fp);/*no of ques*/
	node = node->parent;/*Back to questionbank tag*/
	i = 0;
	for(sprintf(idstr, "%d", (i + 1)), node = mxmlFindElement(node, tree, "question", "id", idstr, MXML_DESCEND_FIRST); node != NULL; node = mxmlFindElement(node, tree, "question", "id", idstr, MXML_DESCEND_FIRST)) {
		node2 = node;/*question tag*/
		printf("Inside the loop %s\n", idstr);
		j = i + 1;
		fwrite(&j, sizeof(int), 1, fp);/*ID*/
		node3 = mxmlFindElement(node2, tree, "type", NULL, NULL, MXML_DESCEND_FIRST);/*type tag*/
		if(!node3) {
			perror("While parsing  no <type> tag found");
			getchar();
			return;
		}
		type = node3->value.integer;
		printf("Element name %s\n", mxmlGetElement(node3));
		printf("Element value %s\n", mxmlGetText(node3,0));
		printf("Type: %d", type);
		fwrite(&type, sizeof(int), 1, fp);/*type*/
		switch(type) {
			case _MCQ: 
				node3 = mxmlFindElement(node2, tree, "questiontext", NULL, NULL, MXML_DESCEND_FIRST);
				if(!node3) {
					perror("While parsing  no <questiontext> tag found");
					getchar();
					return;
				}
				node3 = node3->child;/*text tag*/
				if(!node3) {
					perror("While parsing  no <text> inside <questiontext> tag found");
					getchar();
					return;
				}
				strcpy(qs.ques, node3->child->value.text.string);/*Questiontext*/
				fwrite(&qs,sizeof(struct questionString), 1, fp);/*Storing questionString structure*/
				node3 = mxmlFindElement(node2, tree, "no_of_options", NULL, NULL, MXML_DESCEND_FIRST);/*no_of_option tag*/
				if(!node3) {
					perror("While parsing  no <no_of_options> tag found");
					getchar();
					return;
				}
				fwrite(&(node3->child->value.integer), sizeof(int), 1, fp);/*no of options*/
				j = 0;
				for(sprintf(idstr, "%c", (char)(j + 'A')), node3 = mxmlFindElement(node2, tree, "option", "id", idstr, MXML_DESCEND_FIRST); node3 != NULL; node3 = mxmlFindElement(node2, tree, "option", "id", idstr, MXML_DESCEND_FIRST)) {
					node3 =  mxmlFindElement(node3, tree, "text", NULL, NULL, MXML_DESCEND_FIRST);/*text tag*/
					if(!node3) {
						perror("While parsing  no <text> inside <option> tag found");
						getchar();
						return;
					}
					fwrite(node3->child->value.text.string, sizeof(char) * 20, 1, fp);/*Storing options*/
					j++;
					sprintf(idstr, "%c", (j + 'A'));				
				}
				node3 = mxmlFindElement(node2, tree, "answer", NULL, NULL, MXML_DESCEND_FIRST);/*answer tag*/
				if(!node3) {
						perror("While parsing  no <answer> tag found");
						getchar();
						return;
				}
				fwrite(&(node3->child->value.text.string[0]), sizeof(char), 1, fp);
				break;
			case _MAQ:
				node3 = mxmlFindElement(node2, tree, "questiontext", NULL, NULL, MXML_DESCEND_FIRST);
				if(!node3) {
					perror("While parsing  no <questiontext> tag found");
					getchar();
					return;
				}
				node3 = node3->child;/*text tag*/
				if(!node3) {
					perror("While parsing  no <text> inside <questiontext> tag found");
					getchar();
					return;
				}
				strcpy(qs.ques, node3->child->value.text.string);/*Questiontext*/
				fwrite(&qs,sizeof(struct questionString), 1, fp);/*Storing questionString structure*/
				node3 = mxmlFindElement(node2, tree, "no_of_options", NULL, NULL, MXML_DESCEND_FIRST);/*no_of_option tag*/
				if(!node3) {
					perror("While parsing  no <no_of_options> tag found");
					getchar();
					return;
				}
				fwrite(&(node3->child->value.integer), sizeof(int), 1, fp);/*no of options*/
				j = 0;
				for(sprintf(idstr, "%c", (char)(j + 'A')), node3 = mxmlFindElement(node2, tree, "option", "id", idstr, MXML_DESCEND_FIRST); node3 != NULL; node3 = mxmlFindElement(node2, tree, "option", "id", idstr, MXML_DESCEND_FIRST)) {
					node3 =  mxmlFindElement(node3, tree, "text", NULL, NULL, MXML_DESCEND_FIRST);/*text tag*/
					if(!node3) {
						perror("While parsing  no <text> inside <option> tag found");
						getchar();
						return;
					}
					fwrite(node3->child->value.text.string, sizeof(char) * 20, 1, fp);/*Storing options*/
					j++;
					sprintf(idstr, "%c", (j + 'A'));				
				}
				node3 = mxmlFindElement(node2, tree, "answer", NULL, NULL, MXML_DESCEND_FIRST);/*answer tag*/
				if(!node3) {
						perror("While parsing  no <answer> tag found");
						getchar();
						return;
				}
				/////////////here////////////////////////////////////////////////////
				fwrite(node3->child->value.text.string, sizeof(char), strlen(node3->child->value.text.string) + 1, fp);/*storing string with \0*/
				break;
			case _NAQ:
				node3 = mxmlFindElement(node2, tree, "questiontext", NULL, NULL, MXML_DESCEND_FIRST);
				if(!node3) {
					perror("While parsing  no <questiontext> tag found");
					getchar();
					return;
				}
				node3 = node3->child;/*text tag*/
				if(!node3) {
					perror("While parsing  no <text> inside <questiontext> tag found");
					getchar();
					return;
				}
				strcpy(qs.ques, node3->child->value.text.string);/*Questiontext*/
				naq.qs = qs;
				node3 = mxmlFindElement(node2, tree, "answer", NULL, NULL, MXML_DESCEND_FIRST);
				if(!node3) {
					perror("While parsing  no <answer> tag found for naq");
					getchar();
					return;
				}
				naq.ans = mxmlGetReal(node3->child);/*answer tag*/
				fwrite(&naq, sizeof(NAQ), 1, fp);/*Storing NAQ structure*/
				break;
			case _MTP:
				node3 = mxmlFindElement(node2, tree, "no_of_pairs", NULL, NULL, MXML_DESCEND_FIRST);
				if(!node3) {
					perror("While parsing  no <no_of_pairs> tag found ");
					getchar();
					return;
				}
				fwrite(&(node3->child->value.integer), sizeof(int), 1, fp);/*No of pairs tag*/
				
				j = 0;
				for(sprintf(idstr, "%d", (j + 1)), node3 = mxmlFindElement(node2, tree, "pair", "id", idstr, MXML_DESCEND_FIRST); node3 != NULL; node3 = mxmlFindElement(node2, tree, "pair", "id", idstr, MXML_DESCEND_FIRST)) {
					node3 =  mxmlFindElement(node3, tree, "ques", NULL, NULL, MXML_DESCEND_FIRST);/*ques tag*/
					if(!node3) {
						perror("While parsing  no <ques> inside <pair> tag found");
						getchar();
						return;
					}
					strcpy(pairs.str1, node3->child->value.text.string);
					node3 = node3->parent;
					node3 =  mxmlFindElement(node3, tree, "ans", NULL, NULL, MXML_DESCEND_FIRST);/*ans tag*/
					if(!node3) {
						perror("While parsing  no <ans> inside <pair> tag found");
						getchar();
						return;
					}
					strcpy(pairs.str2, node3->child->value.text.string);
					fwrite(&pairs, sizeof(pair), 1, fp);
					j++;
					sprintf(idstr, "%c", (j + 1));				
				}
				break;
						
		}
		node3 =  mxmlFindElement(node2, tree, "marks", NULL, NULL, MXML_DESCEND_FIRST);
		if(!node3) {
			perror("While parsing  no <marks>  tag found");
			getchar();
			return;
		}
		fwrite(&(node3->child->value.integer), sizeof(int), 1, fp);
		
		i++;
		sprintf(idstr, "%d", (i + 1));
	}
	printf("\nDATA imported\n");
	getchar();
	getchar();
	fclose(fp);
	mxmlDelete(tree);
}

char* convertintoString(int a){
	if(_MCQ || _MAQ)
		return "multichoice";
	else
		return NULL;
}

int found(int* arr, int n, int find){
	int i;
	for(i = 0; i < n; i++) {
		if(arr[i] == find)
			return 1;
	}
	return 0;
}
void export2(char* filename) {
	char temp[100], idstr[6], **optionstr, str[20], correctfrac[20], incorrectfrac[20], ch;
	int anslen, *arr;
	pair* p;
	int id;
	int i, j, k = 0, mark = 0, ans;
	questionString qs;
	NAQ naq;
	FILE* fp;
	mxml_node_t *xml, *quiz, *value, *question, *category, *name, *questiontext, *text, *genfd, *answer, *no_of_pairs, *pairN, *ques;
	strcpy(temp, "./QuestionBank/");/*./QuestionBank/filename.qb*/
	strcat(temp, filename);
	strcat(temp, ".qb");
	fp = fopen(temp, "r");
	//printf("%s\n", file_name);
	
	if(!fp) {
		perror("Cant open file ");
		getchar();
		return;
	}
	xml = mxmlNewXML("1.0");//Xml tag
	quiz = mxmlNewElement(xml, "quiz");/*questionbank*/
	//mxmlElementSetAttr(questionbank, "name", filename);/*name attr*/
	fread(&i, sizeof(int), 1, fp);/*READ no of ques*/
	question = mxmlNewElement(quiz, "question");
	mxmlElementSetAttr(question, "type", "category");
	category = mxmlNewElement(question, "category");
	text = mxmlNewElement(category, "text");
	value = mxmlNewText(text, 0, filename);
	//no_of_ques = mxmlNewElement(questionbank, "no_of_ques");
	//value = mxmlNewInteger(no_of_ques, i);/*no of ques*/
	
	while(fread(&id, sizeof(int), 1, fp) != 0) {/*READ question ID*/
		question = mxmlNewElement(quiz,"question");/*question tag*/
		fread(&i, sizeof(int), 1, fp);/*READ ques type*/
		mxmlElementSetAttr(question, "type", convertintoString(i));
		name = mxmlNewElement(question, "name");
		text = mxmlNewElement(name, "text");
		sprintf(idstr, "%d", id);
		strcpy(temp, "Question : ");
		strcat(temp, idstr);
		value = mxmlNewText(text, 0, temp);

		switch(i) {
			case _MCQ: 
				fread(&qs,sizeof(struct questionString), 1, fp);/*Storing questionString structure*/
				questiontext = mxmlNewElement(question, "questiontext");
				text = mxmlNewElement(questiontext, "text");
				value = mxmlNewText(text, 0, qs.ques);
				genfd = mxmlNewElement(question, "generalfeedback");
				mxmlElementSetAttr(genfd, "format", "html");
				text = mxmlNewElement(genfd, "text");
				genfd = mxmlNewElement(question, "defaultgrade");
				value = mxmlNewReal(genfd, 1.0);
				genfd = mxmlNewElement(question, "penalty");
				value = mxmlNewReal(genfd, (double)1/3);
				genfd = mxmlNewElement(question, "hidden");
				value = mxmlNewInteger(genfd, 0);
				genfd = mxmlNewElement(question, "single");
				value = mxmlNewText(genfd, 0, "true");
				genfd = mxmlNewElement(question, "shuffleanswers");
				value = mxmlNewText(genfd, 0, "true");
				genfd = mxmlNewElement(question, "answernumbering");
				value = mxmlNewText(genfd, 0, "abc");
				genfd = mxmlNewElement(question, "correctfeedback");
				mxmlElementSetAttr(genfd, "format", "html");
				text = mxmlNewElement(genfd, "text");
				value = mxmlNewText(text, 0, "Your answer is Correct.");
				genfd = mxmlNewElement(question, "partiallycorrectfeedback");
				mxmlElementSetAttr(genfd, "format", "html");
				text = mxmlNewElement(genfd, "text");
				genfd = mxmlNewElement(question, "incorrectfeedback");
				mxmlElementSetAttr(genfd, "format", "html");
				text = mxmlNewElement(genfd, "text");
				value = mxmlNewText(text, 0, "Your answer is Incorrect.");

				fread(&i, sizeof(int), 1, fp);/*no of options*/
				optionstr = (char**)malloc(sizeof(char*) * i);
				for(j = 0; j < i; j++) {
					optionstr[j] = (char*)malloc(sizeof(char) * 20);
				}
				j = 0;
				while(j < i) {

					fread(optionstr[j], sizeof(char) , 20, fp);/*Reading options*/
					j++;
							
				}
				fread(&ch, sizeof(char), 1, fp);
				ans = (int) ch - 'A';
				j = 0;
				while(j < i) {

					answer = mxmlNewElement(question, "answer");
					mxmlElementSetAttr(answer, "format", "html");
					if(j == ans) {
						mxmlElementSetAttr(answer, "fraction", "100");
					}
					else {
						mxmlElementSetAttr(answer, "fraction", "0");
					}
					text = mxmlNewElement(answer, "text");
					value = mxmlNewText(text, 0, optionstr[j]);
					genfd = mxmlNewElement(answer, "feedback");
					mxmlElementSetAttr(genfd, "format", "html");
					text = mxmlNewElement(genfd, "text");
					j++;
							
				}
				for(j = 0; j < i; j++) {
					free(optionstr[j]);
				}
				break;
			case _MAQ: 
				fread(&qs,sizeof(struct questionString), 1, fp);/*Storing questionString structure*/
				questiontext = mxmlNewElement(question, "questiontext");
				text = mxmlNewElement(questiontext, "text");
				value = mxmlNewText(text, 0, qs.ques);
				genfd = mxmlNewElement(question, "generalfeedback");
				mxmlElementSetAttr(genfd, "format", "html");
				text = mxmlNewElement(genfd, "text");
				genfd = mxmlNewElement(question, "defaultgrade");
				value = mxmlNewReal(genfd, 1.0);
				genfd = mxmlNewElement(question, "penalty");
				value = mxmlNewReal(genfd, (double)1/3);
				genfd = mxmlNewElement(question, "hidden");
				value = mxmlNewInteger(genfd, 0);
				genfd = mxmlNewElement(question, "single");
				value = mxmlNewText(genfd, 0, "false");
				genfd = mxmlNewElement(question, "shuffleanswers");
				value = mxmlNewText(genfd, 0, "true");
				genfd = mxmlNewElement(question, "answernumbering");
				value = mxmlNewText(genfd, 0, "abc");
				genfd = mxmlNewElement(question, "correctfeedback");
				mxmlElementSetAttr(genfd, "format", "html");
				text = mxmlNewElement(genfd, "text");
				value = mxmlNewText(text, 0, "Your answer is Correct.");
				genfd = mxmlNewElement(question, "partiallycorrectfeedback");
				mxmlElementSetAttr(genfd, "format", "html");
				text = mxmlNewElement(genfd, "text");
				genfd = mxmlNewElement(question, "incorrectfeedback");
				mxmlElementSetAttr(genfd, "format", "html");
				text = mxmlNewElement(genfd, "text");
				value = mxmlNewText(text, 0, "Your answer is Incorrect.");

				fread(&i, sizeof(int), 1, fp);/*no of options*/
				optionstr = (char**)malloc(sizeof(char*) * i);
				for(j = 0; j < i; j++) {
					optionstr[j] = (char*)malloc(sizeof(char) * 20);
				}
				j = 0;
				while(j < i) {

					fread(optionstr[j], sizeof(char) , 20, fp);/*Reading options*/
					j++;
							
				}
				arr = (int*) malloc(sizeof(int) * i);
				
				j = 0;
				do {
					fread(&ch, sizeof(char), 1, fp);/*reading ans till '\0'*/
					str[j] = ch;
					arr[j] = ch - 'A';
					j++;
				}while(ch != '\0');
				anslen = strlen(str);
				sprintf(correctfrac, "%.5f", ((float)1/anslen) * 100);
				if(i != anslen)
					sprintf(incorrectfrac, "%.5f", -((float)1/(i - anslen)) * 100);
				else
					sprintf(incorrectfrac, "%f", (float)0);
				j = 0;
				while(j < i) {

					answer = mxmlNewElement(question, "answer");
					mxmlElementSetAttr(answer, "format", "html");
					if(found(arr, anslen, j) == 1) {
						mxmlElementSetAttr(answer, "fraction", correctfrac);
					}
					else {
						mxmlElementSetAttr(answer, "fraction", incorrectfrac);
					}
					text = mxmlNewElement(answer, "text");
					value = mxmlNewText(text, 0, optionstr[j]);
					genfd = mxmlNewElement(answer, "feedback");
					mxmlElementSetAttr(genfd, "format", "html");
					text = mxmlNewElement(genfd, "text");
					j++;
							
				}
				
				break;
				
		}
		
		//fread(&mark, sizeof(int), 1, fp);
		//marks = mxmlNewElement(question, "marks");
		//value = mxmlNewInteger(marks, 0);
		
	}
	fclose(fp);
	printf("Enter a name for xml file:");
	scanf("%s", filename);
	getchar();
	strcpy(temp, "./Export_Files/");/*./QuestionBank/filename.qb*/
	strcat(temp, filename);
	strcat(temp, ".xml");
	fp = fopen(temp, "w");
	if(!fp) {
		perror("Cant open file ");
		getchar();
		return;
	}
	mxmlSaveFile(xml, fp, MXML_NO_CALLBACK);
	printf("\nData exported successfully.........\n");
	fclose(fp);
	mxmlDelete(xml);/*Delete the tree*/
}
