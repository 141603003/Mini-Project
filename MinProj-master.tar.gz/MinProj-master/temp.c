fetchquiz(question_ll* questionarr, char* filename){
	int no_of_ques, i, id, type, temp, j;
	option_ptr opt_ptr;
	questionString qs;
	pair* p;
	NAQ naq;
	char str[20], ans;
	FILE* fp = fopen(filename, "r");
	if(!fp) {
		perror("Cant open file ");
		return;
	}
	fread(&no_of_ques, sizeof(int), 1, fp);/*no of ques*/
	questionarr = NULL;
	questionarr = (question_ll*)malloc(sizeof(question_ll) * no_of_ques);
	for(i = 0; i < no_of_ques; i++) {
		fread(&id, sizeof(int), 1, fp);
		questionarr[i].q.id = id;/*ID*/
		fread(&type, sizeof(int), 1, fp);/*ques type*/
		questionarr[i].q.type_of_ques = type;/*Question type*/
		switch(type) {
			case _MCQ: 
				fread(&qs,sizeof(struct questionString), 1, fp);/*Reading questionString structure*/
				questionarr[i].q.ques.mcq.qs = qs;
				fread(&temp, sizeof(int), 1, fp);/*no of options*/
				questionarr[i].q.ques.mcq.no_of_opt = temp;/*No of options*/
				/*option list*/
				opt_ptr.start = NULL;
				j = 0;
				while(j < temp) {

					fread(&str, sizeof(char) , 20, fp);/*Reading options*/	
					addOptionQuiz(&opt_ptr, str);
					j++;
							
				}
				questionarr[i].q.ques.mcq.opts = opt_ptr.start;/*adding option*/
				fread(&ans, sizeof(char), 1, fp);
				questionarr[i].q.ques.mcq.ans = ans;/*Answer*/
				break;
			case _MAQ:
				fread(&qs,sizeof(struct questionString), 1, fp);/*Reading questionString structure*/
				questionarr[i].q.ques.maq.qs = qs;
				fread(&temp, sizeof(int), 1, fp);/*no of options*/
				questionarr[i].q.ques.maq.no_of_opt = temp;/*No of options*/
				/*option list*/
				opt_ptr.start = NULL;
				j = 0;
				while(j < temp) {

					fread(&str, sizeof(char) , 20, fp);/*Reading options*/	
					addOptionQuiz(&opt_ptr, str);
					j++;
							
				}
				questionarr[i].q.ques.maq.opts = opt_ptr.start;/*adding option*/
				j = 0;
				do {
					fread(&ch, sizeof(char), 1, fp);/*reading ans till '\0'*/
					str[j] = ch;
					j++;
				}while(ch != '\0');
				questionarr[i].q.ques.maq.ans = (char*)malloc(sizeof(char) * i + 1);/*i contains number of options*/
				strcpy(questionarr[i].q.ques.maq.ans, str);			
				break;
			case _NAQ:
				fread(&naq, sizeof(NAQ), 1, fp);
				questionarr[i].q.ques.naq = naq;
				break;	
			case _MTP:
				fread(&temp, sizeof(int), 1,fp);/*no of pairs*/
				questionarr[i].q.ques.mtp.no_of_pairs = temp;
				questionarr[i].q.ques.mtp.pairs = NULL;
				p = (pair*)malloc(sizeof(pair));
				//if(p == NULL) printf("Memory allocated");
				for(j = 0; j < temp; j++) {
					fread(p, sizeof(pair), 1, fp);
					addPairsQuiz(&(questionarr[i].q.ques.mtp), p); /*Adding pairs*/
								
				}
				break;	
		}
		fread(&temp, sizeof(int), 1, fp);
		questionarr[i].marks = temp;
		questionarr[i].next = NULL;	
	}
}
