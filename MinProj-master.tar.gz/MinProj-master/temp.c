void export(char* filename) {
	char temp[100], idstr[5];
	pair* p;
	int i, j, k = 0, mark = 0;
	questionString qs;
	NAQ naq;
	char str[20], ch;
	FILE* fp;
	mxml_node_t *xml, *questionbank, *no_of_ques, *value, *question, *marks, *type, *questiontext, *text, *no_of_options, *option, *answer, *id, *no_of_pairs, *pairN, *ques, *ans;
	strcpy(temp, "./QuestionBank/");/*./QuestionBank/filename.qb*/
	strcat(temp, filename);
	strcat(temp, ".qb");
	fp = fopen(temp, "r");
	//printf("%s\n", file_name);
	
	if(!fp) {
		perror("Cant open file ");
		getchar();
		return;
	}
	xml = mxmlNewXML("1.0");//Xml tag
	questionbank = mxmlNewElement(xml, "questionbank");/*questionbank*/
	mxmlElementSetAttr(questionbank, "name", filename);/*name attr*/
	fread(&i, sizeof(int), 1, fp);/*no of ques*/
	no_of_ques = mxmlNewElement(questionbank, "no_of_ques");
	value = mxmlNewInteger(no_of_ques, i);/*no of ques*/
	
	while(fread(&i, sizeof(int), 1, fp) != 0) {/*question ID*/
		question = mxmlNewElement(questionbank,"question");/*question tag*/
		sprintf(idstr, "%d", i);
		mxmlElementSetAttr(question, "id", idstr);
		fread(&i, sizeof(int), 1, fp);/*ques type*/
		type = mxmlNewElement(question, "type");
		value = mxmlNewInteger(type, i);
		switch(i) {
			case _MCQ: 
				fread(&qs,sizeof(struct questionString), 1, fp);/*Storing questionString structure*/
				questiontext = mxmlNewElement(question, "questiontext");
				text = mxmlNewElement(questiontext, "text");
				value = mxmlNewText(text, 0, qs.ques);
				fread(&i, sizeof(int), 1, fp);/*no of options*/
				no_of_options = mxmlNewElement(question, "no_of_options");
				value = mxmlNewInteger(no_of_options, i);
				j = 0;
				while(j < i) {

					fread(&str, sizeof(char) , 20, fp);/*Reading options*/
					option = mxmlNewElement(question, "option");
					sprintf(idstr, "%c", (char)(j + 1 + 64));
					mxmlElementSetAttr(option, "id", idstr);
					text = mxmlNewElement(option, "text");
					value = mxmlNewText(text, 0, str);
					
					j++;
							
				}
				fread(&ch, sizeof(char), 1, fp);
				answer = mxmlNewElement(question, "answer");
				sprintf(idstr, "%c", ch);
				value = mxmlNewText(answer, 0, idstr);
				break;
			case _MAQ:
				fread(&qs,sizeof(struct questionString), 1, fp);/*Storing questionString structure*/
				questiontext = mxmlNewElement(question, "questiontext");
				text = mxmlNewElement(questiontext, "text");
				value = mxmlNewText(text, 0, qs.ques);
				fread(&i, sizeof(int), 1, fp);/*no of options*/
				no_of_options = mxmlNewElement(question, "no_of_options");
				value = mxmlNewInteger(no_of_options, i);
				j = 0;
				while(j < i) {

					fread(&str, sizeof(char) , 20, fp);/*Reading options*/
					option = mxmlNewElement(question, "option");
					sprintf(idstr, "%c", (char)(j + 1 + 64));
					mxmlElementSetAttr(option, "id", idstr);
					text = mxmlNewElement(option, "text");
					value = mxmlNewText(text, 0, str);
					
					j++;
							
				}
				j = 0;
				do {
					fread(&ch, sizeof(char), 1, fp);/*reading ans till '\0'*/
					str[j] = ch;
					j++;
				}while(ch != '\0');
				answer = mxmlNewElement(question, "answer");
		
				value = mxmlNewText(answer, 0, str);			
				break;
			case _NAQ:
				fread(&naq, sizeof(NAQ), 1, fp);
				qs = naq.qs;
				questiontext = mxmlNewElement(question, "questiontext");
				text = mxmlNewElement(questiontext, "text");
				value = mxmlNewText(text, 0, qs.ques);
				answer = mxmlNewElement(question, "answer");
				value = mxmlNewReal(answer, naq.ans);
				break;	
			case _MTP:
				fread(&i, sizeof(int), 1,fp);
				no_of_pairs = mxmlNewElement(question, "no_of_pairs");
				value = mxmlNewInteger(no_of_pairs, i);
				p = (pair*) malloc(sizeof(pair));

				if(p == NULL) {printf("Memory not allocated");}
				for(j = 0; j < i; j++) {
					fread(p, sizeof(pair), 1, fp);
					pairN = mxmlNewElement(question, "pair");
					sprintf(idstr, "%c", (char)(j + 1 + 64));
					mxmlElementSetAttr(pairN, "id", idstr);
					ques = mxmlNewElement(pairN, "ques");
					value = mxmlNewText(ques, 0, p->str1);
					ans = mxmlNewElement(pairN, "ans");
					value = mxmlNewText(ans, 0, p->str2);
								
				}
				free(p);
				break;	
		}
		
		//fread(&mark, sizeof(int), 1, fp);
		marks = mxmlNewElement(question, "marks");
		value = mxmlNewInteger(marks, 0);
		
	}
	fclose(fp);
	printf("Enter a name for xml file:");
	scanf("%s", filename);
	getchar();
	strcpy(temp, "./Export_Files/");/*./QuestionBank/filename.qb*/
	strcat(temp, filename);
	strcat(temp, ".xml");
	fp = fopen(temp, "w");
	if(!fp) {
		perror("Cant open file ");
		getchar();
		return;
	}
	mxmlSaveFile(xml, fp, MXML_NO_CALLBACK);
	printf("\nData exported successfully.........\n");
	fclose(fp);
	mxmlDelete(xml);/*Delete the tree*/
}

void import(char* filename) {/*Assume .xml extension*/
	char temp[100], str[100], idstr[10];
	int i = 0, j = 0, type;
	FILE* fp;
	mxml_node_t *tree;
	mxml_node_t *node, *node2, *node3;
	questionString qs;
	NAQ naq;
	pair pairs;
	 
	if(filename[0] != '/') {
		strcpy(temp, "./");
		strcat(temp, filename);
    	}
	else {
		strcpy(temp, filename);
	}
	fp = fopen(temp, "r");
	if(!fp) {
		perror("Cant open file ");
		getchar();
		return;
	}
	tree = mxmlLoadFile(NULL, fp, MXML_TEXT_CALLBACK);/*Fetching the whole tree*/
	fclose(fp);
	
	if(!tree) {
		errno = EINVAL;
		perror("Not an XML file");
		return;
	}

	//printf("\nEnter a name for this new Question Bank:\n");
	//scanf("%s", filename);
	node = tree->child;//questionbank tag
	strcpy(str, mxmlElementGetAttr(node, "name"));/*name of qb*/
	if(!str) {
		perror("While parsing questionbank tag no name attribute found");
		getchar();
		return;
	}
	strcpy(temp, "./QuestionBank/");
	strcat(temp, str);
	strcat(temp, ".qb");
	fp = fopen(temp , "w");
	if(!fp) {
		perror("Cant open file ");
		getchar();
		return;
	}
	/*Search no_of_ques*/
	node = mxmlFindElement (node, tree, "no_of_ques", NULL, NULL, MXML_DESCEND_FIRST);/*search just 1 level inside*/
	if(!node) {
		perror("While parsing  no <no_of_ques> tag found");
		getchar();
		return;
	}
	fwrite(&(node->child->value.integer), sizeof(int), 1, fp);/*no of ques*/
	node = node->parent;/*Back to questionbank tag*/
	i = 0;
	for(sprintf(idstr, "%d", (i + 1)), node = mxmlFindElement(node, tree, "question", "id", idstr, MXML_DESCEND_FIRST); node != NULL; node = mxmlFindElement(node, tree, "question", "id", idstr, MXML_DESCEND_FIRST)) {
		node2 = node;/*question tag*/
		printf("Inside the loop %s\n", idstr);
		j = i + 1;
		fwrite(&j, sizeof(int), 1, fp);/*ID*/
		node3 = mxmlFindElement(node2, tree, "type", NULL, NULL, MXML_DESCEND_FIRST);/*type tag*/
		if(!node3) {
			perror("While parsing  no <type> tag found");
			getchar();
			return;
		}
		type = node3->value.integer;
		printf("Element name %s\n", mxmlGetElement(node3));
		printf("Element value %s\n", mxmlGetText(node3,0));
		printf("Type: %d", type);
		fwrite(&type, sizeof(int), 1, fp);/*type*/
		switch(type) {
			case _MCQ: 
				node3 = mxmlFindElement(node2, tree, "questiontext", NULL, NULL, MXML_DESCEND_FIRST);
				if(!node3) {
					perror("While parsing  no <questiontext> tag found");
					getchar();
					return;
				}
				node3 = node3->child;/*text tag*/
				if(!node3) {
					perror("While parsing  no <text> inside <questiontext> tag found");
					getchar();
					return;
				}
				strcpy(qs.ques, node3->child->value.text.string);/*Questiontext*/
				fwrite(&qs,sizeof(struct questionString), 1, fp);/*Storing questionString structure*/
				node3 = mxmlFindElement(node2, tree, "no_of_options", NULL, NULL, MXML_DESCEND_FIRST);/*no_of_option tag*/
				if(!node3) {
					perror("While parsing  no <no_of_options> tag found");
					getchar();
					return;
				}
				fwrite(&(node3->child->value.integer), sizeof(int), 1, fp);/*no of options*/
				j = 0;
				for(sprintf(idstr, "%c", (char)(j + 'A')), node3 = mxmlFindElement(node2, tree, "option", "id", idstr, MXML_DESCEND_FIRST); node3 != NULL; node3 = mxmlFindElement(node2, tree, "option", "id", idstr, MXML_DESCEND_FIRST)) {
					node3 =  mxmlFindElement(node3, tree, "text", NULL, NULL, MXML_DESCEND_FIRST);/*text tag*/
					if(!node3) {
						perror("While parsing  no <text> inside <option> tag found");
						getchar();
						return;
					}
					fwrite(node3->child->value.text.string, sizeof(char) * 20, 1, fp);/*Storing options*/
					j++;
					sprintf(idstr, "%c", (j + 'A'));				
				}
				node3 = mxmlFindElement(node2, tree, "answer", NULL, NULL, MXML_DESCEND_FIRST);/*answer tag*/
				if(!node3) {
						perror("While parsing  no <answer> tag found");
						getchar();
						return;
				}
				fwrite(&(node3->child->value.text.string[0]), sizeof(char), 1, fp);
				break;
			case _MAQ:
				node3 = mxmlFindElement(node2, tree, "questiontext", NULL, NULL, MXML_DESCEND_FIRST);
				if(!node3) {
					perror("While parsing  no <questiontext> tag found");
					getchar();
					return;
				}
				node3 = node3->child;/*text tag*/
				if(!node3) {
					perror("While parsing  no <text> inside <questiontext> tag found");
					getchar();
					return;
				}
				strcpy(qs.ques, node3->child->value.text.string);/*Questiontext*/
				fwrite(&qs,sizeof(struct questionString), 1, fp);/*Storing questionString structure*/
				node3 = mxmlFindElement(node2, tree, "no_of_options", NULL, NULL, MXML_DESCEND_FIRST);/*no_of_option tag*/
				if(!node3) {
					perror("While parsing  no <no_of_options> tag found");
					getchar();
					return;
				}
				fwrite(&(node3->child->value.integer), sizeof(int), 1, fp);/*no of options*/
				j = 0;
				for(sprintf(idstr, "%c", (char)(j + 'A')), node3 = mxmlFindElement(node2, tree, "option", "id", idstr, MXML_DESCEND_FIRST); node3 != NULL; node3 = mxmlFindElement(node2, tree, "option", "id", idstr, MXML_DESCEND_FIRST)) {
					node3 =  mxmlFindElement(node3, tree, "text", NULL, NULL, MXML_DESCEND_FIRST);/*text tag*/
					if(!node3) {
						perror("While parsing  no <text> inside <option> tag found");
						getchar();
						return;
					}
					fwrite(node3->child->value.text.string, sizeof(char) * 20, 1, fp);/*Storing options*/
					j++;
					sprintf(idstr, "%c", (j + 'A'));				
				}
				node3 = mxmlFindElement(node2, tree, "answer", NULL, NULL, MXML_DESCEND_FIRST);/*answer tag*/
				if(!node3) {
						perror("While parsing  no <answer> tag found");
						getchar();
						return;
				}
				/////////////here////////////////////////////////////////////////////
				fwrite(node3->child->value.text.string, sizeof(char), strlen(node3->child->value.text.string) + 1, fp);/*storing string with \0*/
				break;
			case _NAQ:
				node3 = mxmlFindElement(node2, tree, "questiontext", NULL, NULL, MXML_DESCEND_FIRST);
				if(!node3) {
					perror("While parsing  no <questiontext> tag found");
					getchar();
					return;
				}
				node3 = node3->child;/*text tag*/
				if(!node3) {
					perror("While parsing  no <text> inside <questiontext> tag found");
					getchar();
					return;
				}
				strcpy(qs.ques, node3->child->value.text.string);/*Questiontext*/
				naq.qs = qs;
				node3 = mxmlFindElement(node2, tree, "answer", NULL, NULL, MXML_DESCEND_FIRST);
				if(!node3) {
					perror("While parsing  no <answer> tag found for naq");
					getchar();
					return;
				}
				naq.ans = mxmlGetReal(node3->child);/*answer tag*/
				fwrite(&naq, sizeof(NAQ), 1, fp);/*Storing NAQ structure*/
				break;
			case _MTP:
				node3 = mxmlFindElement(node2, tree, "no_of_pairs", NULL, NULL, MXML_DESCEND_FIRST);
				if(!node3) {
					perror("While parsing  no <no_of_pairs> tag found ");
					getchar();
					return;
				}
				fwrite(&(node3->child->value.integer), sizeof(int), 1, fp);/*No of pairs tag*/
				
				j = 0;
				for(sprintf(idstr, "%d", (j + 1)), node3 = mxmlFindElement(node2, tree, "pair", "id", idstr, MXML_DESCEND_FIRST); node3 != NULL; node3 = mxmlFindElement(node2, tree, "pair", "id", idstr, MXML_DESCEND_FIRST)) {
					node3 =  mxmlFindElement(node3, tree, "ques", NULL, NULL, MXML_DESCEND_FIRST);/*ques tag*/
					if(!node3) {
						perror("While parsing  no <ques> inside <pair> tag found");
						getchar();
						return;
					}
					strcpy(pairs.str1, node3->child->value.text.string);
					node3 = node3->parent;
					node3 =  mxmlFindElement(node3, tree, "ans", NULL, NULL, MXML_DESCEND_FIRST);/*ans tag*/
					if(!node3) {
						perror("While parsing  no <ans> inside <pair> tag found");
						getchar();
						return;
					}
					strcpy(pairs.str2, node3->child->value.text.string);
					fwrite(&pairs, sizeof(pair), 1, fp);
					j++;
					sprintf(idstr, "%c", (j + 1));				
				}
				break;
						
		}
		node3 =  mxmlFindElement(node2, tree, "marks", NULL, NULL, MXML_DESCEND_FIRST);
		if(!node3) {
			perror("While parsing  no <marks>  tag found");
			getchar();
			return;
		}
		fwrite(&(node3->child->value.integer), sizeof(int), 1, fp);
		
		i++;
		sprintf(idstr, "%d", (i + 1));
	}
	printf("\nDATA imported\n");
	getchar();
	getchar();
	fclose(fp);
	mxmlDelete(tree);
}

char* convertintoString(int a){
	if(a == _MCQ || a == _MAQ)
		return "multichoice";
	else if(a == _NAQ)
		return "numerical";
	else if(a == _MTP)
		return "matching";
	return NULL;
}

int found(int* arr, int n, int find){
	int i;
	for(i = 0; i < n; i++) {
		if(arr[i] == find)
			return 1;
	}
	return 0;
}
void export2(char* filename) {
	char temp[100], idstr[6], **optionstr, str[20], correctfrac[20], incorrectfrac[20], ch;
	int anslen, *arr;
	NAQ naq;
	pair* p;
	int id;
	int i, j, k = 0, mark = 0, ans;
	questionString qs;
	
	FILE* fp;
	mxml_node_t *xml, *quiz, *value, *question, *category, *name, *questiontext, *text, *genfd, *answer, *no_of_pairs, *pairN, *ques;
	strcpy(temp, "./QuestionBank/");/*./QuestionBank/filename.qb*/
	strcat(temp, filename);
	strcat(temp, ".qb");
	fp = fopen(temp, "r");
	//printf("%s\n", file_name);
	
	if(!fp) {
		perror("Cant open file ");
		getchar();
		return;
	}
	xml = mxmlNewXML("1.0");//Xml tag
	quiz = mxmlNewElement(xml, "quiz");/*questionbank*/
	//mxmlElementSetAttr(questionbank, "name", filename);/*name attr*/
	fread(&i, sizeof(int), 1, fp);/*READ no of ques*/
	question = mxmlNewElement(quiz, "question");
	mxmlElementSetAttr(question, "type", "category");
	category = mxmlNewElement(question, "category");
	text = mxmlNewElement(category, "text");
	value = mxmlNewText(text, 0, filename);
	//no_of_ques = mxmlNewElement(questionbank, "no_of_ques");
	//value = mxmlNewInteger(no_of_ques, i);/*no of ques*/
	
	while(fread(&id, sizeof(int), 1, fp) != 0) {/*READ question ID*/
		question = mxmlNewElement(quiz,"question");/*question tag*/
		fread(&i, sizeof(int), 1, fp);/*READ ques type*/
		mxmlElementSetAttr(question, "type", convertintoString(i));
		name = mxmlNewElement(question, "name");
		text = mxmlNewElement(name, "text");
		sprintf(idstr, "%d", id);
		strcpy(temp, "Question : ");
		strcat(temp, idstr);
		value = mxmlNewText(text, 0, temp);

		switch(i) {
			case _MCQ: 
				fread(&qs,sizeof(struct questionString), 1, fp);/*Storing questionString structure*/
				questiontext = mxmlNewElement(question, "questiontext");
				mxmlElementSetAttr(questiontext, "format", "html");
				text = mxmlNewElement(questiontext, "text");
				value = mxmlNewCDATA(text, qs.ques);//here
				genfd = mxmlNewElement(question, "generalfeedback");
				mxmlElementSetAttr(genfd, "format", "html");
				text = mxmlNewElement(genfd, "text");
				genfd = mxmlNewElement(question, "defaultgrade");
				value = mxmlNewReal(genfd, 1.0);
				genfd = mxmlNewElement(question, "penalty");
				value = mxmlNewReal(genfd, (double)1/3);
				genfd = mxmlNewElement(question, "hidden");
				value = mxmlNewInteger(genfd, 0);
				genfd = mxmlNewElement(question, "single");
				value = mxmlNewText(genfd, 0, "true");
				genfd = mxmlNewElement(question, "shuffleanswers");
				value = mxmlNewText(genfd, 0, "true");
				genfd = mxmlNewElement(question, "answernumbering");
				value = mxmlNewText(genfd, 0, "abc");
				genfd = mxmlNewElement(question, "correctfeedback");
				mxmlElementSetAttr(genfd, "format", "html");
				text = mxmlNewElement(genfd, "text");
				value = mxmlNewText(text, 0, "Your answer is Correct.");
				genfd = mxmlNewElement(question, "partiallycorrectfeedback");
				mxmlElementSetAttr(genfd, "format", "html");
				text = mxmlNewElement(genfd, "text");
				genfd = mxmlNewElement(question, "incorrectfeedback");
				mxmlElementSetAttr(genfd, "format", "html");
				text = mxmlNewElement(genfd, "text");
				value = mxmlNewText(text, 0, "Your answer is Incorrect.");

				fread(&i, sizeof(int), 1, fp);/*no of options*/
				optionstr = (char**)malloc(sizeof(char*) * i);
				for(j = 0; j < i; j++) {
					optionstr[j] = (char*)malloc(sizeof(char) * 20);
				}
				j = 0;
				while(j < i) {

					fread(optionstr[j], sizeof(char) , 20, fp);/*Reading options*/
					j++;
							
				}
				fread(&ch, sizeof(char), 1, fp);
				ans = (int) ch - 'A';
				j = 0;
				while(j < i) {

					answer = mxmlNewElement(question, "answer");
					mxmlElementSetAttr(answer, "format", "html");
					if(j == ans) {
						mxmlElementSetAttr(answer, "fraction", "100");
					}
					else {
						mxmlElementSetAttr(answer, "fraction", "0");
					}
					text = mxmlNewElement(answer, "text");
					value = mxmlNewCDATA(text, optionstr[j]);//here
					genfd = mxmlNewElement(answer, "feedback");
					mxmlElementSetAttr(genfd, "format", "html");
					text = mxmlNewElement(genfd, "text");
					j++;
							
				}
				for(j = 0; j < i; j++) {
					free(optionstr[j]);
				}
				break;
			case _MAQ: 
				fread(&qs,sizeof(struct questionString), 1, fp);/*Storing questionString structure*/
				questiontext = mxmlNewElement(question, "questiontext");
				mxmlElementSetAttr(questiontext, "format", "html");
				text = mxmlNewElement(questiontext, "text");
				value = mxmlNewCDATA(text,  qs.ques);//here
				genfd = mxmlNewElement(question, "generalfeedback");
				mxmlElementSetAttr(genfd, "format", "html");
				text = mxmlNewElement(genfd, "text");
				genfd = mxmlNewElement(question, "defaultgrade");
				value = mxmlNewReal(genfd, 1.0);
				genfd = mxmlNewElement(question, "penalty");
				value = mxmlNewReal(genfd, (double)1/3);
				genfd = mxmlNewElement(question, "hidden");
				value = mxmlNewInteger(genfd, 0);
				genfd = mxmlNewElement(question, "single");
				value = mxmlNewText(genfd, 0, "false");
				genfd = mxmlNewElement(question, "shuffleanswers");
				value = mxmlNewText(genfd, 0, "true");
				genfd = mxmlNewElement(question, "answernumbering");
				value = mxmlNewText(genfd, 0, "abc");
				genfd = mxmlNewElement(question, "correctfeedback");
				mxmlElementSetAttr(genfd, "format", "html");
				text = mxmlNewElement(genfd, "text");
				value = mxmlNewText(text, 0, "Your answer is Correct.");
				genfd = mxmlNewElement(question, "partiallycorrectfeedback");
				mxmlElementSetAttr(genfd, "format", "html");
				text = mxmlNewElement(genfd, "text");
				value = mxmlNewText(text, 0, "Your answer is partially correct.");
				genfd = mxmlNewElement(question, "incorrectfeedback");
				mxmlElementSetAttr(genfd, "format", "html");
				text = mxmlNewElement(genfd, "text");
				value = mxmlNewText(text, 0, "Your answer is Incorrect.");

				fread(&i, sizeof(int), 1, fp);/*no of options*/
				optionstr = (char**)malloc(sizeof(char*) * i);
				for(j = 0; j < i; j++) {
					optionstr[j] = (char*)malloc(sizeof(char) * 20);
				}
				j = 0;
				while(j < i) {

					fread(optionstr[j], sizeof(char) , 20, fp);/*Reading options*/
					j++;
							
				}
				arr = (int*) malloc(sizeof(int) * i);
				
				j = 0;
				do {
					fread(&ch, sizeof(char), 1, fp);/*reading ans till '\0'*/
					str[j] = ch;
					arr[j] = ch - 'A';
					j++;
				}while(ch != '\0');
				anslen = strlen(str);
				sprintf(correctfrac, "%.5f", ((float)1/anslen) * 100);
				if(i != anslen)
					sprintf(incorrectfrac, "%.5f", -((float)1/(i - anslen)) * 100);
				else
					sprintf(incorrectfrac, "%f", (float)0);
				j = 0;
				while(j < i) {

					answer = mxmlNewElement(question, "answer");
					mxmlElementSetAttr(answer, "format", "html");
					if(found(arr, anslen, j) == 1) {
						mxmlElementSetAttr(answer, "fraction", correctfrac);
					}
					else {
						mxmlElementSetAttr(answer, "fraction", incorrectfrac);
					}
					text = mxmlNewElement(answer, "text");
					value = mxmlNewCDATA(text, optionstr[j]);
					genfd = mxmlNewElement(answer, "feedback");
					mxmlElementSetAttr(genfd, "format", "html");
					text = mxmlNewElement(genfd, "text");
					j++;
							
				}
				
				break;
			case _NAQ:
			
				fread(&naq, sizeof(NAQ), 1, fp);
				qs = naq.qs;
				questiontext = mxmlNewElement(question, "questiontext");
				mxmlElementSetAttr(questiontext, "format", "html");
				text = mxmlNewElement(questiontext, "text");
				value = mxmlNewCDATA(text,qs.ques);//here
				genfd = mxmlNewElement(question, "generalfeedback");
				mxmlElementSetAttr(genfd, "format", "html");
				text = mxmlNewElement(genfd, "text");
				genfd = mxmlNewElement(question, "defaultgrade");
				value = mxmlNewReal(genfd, 1.0);
				genfd = mxmlNewElement(question, "penalty");
				value = mxmlNewReal(genfd, (double)1/3);
				genfd = mxmlNewElement(question, "hidden");
				value = mxmlNewInteger(genfd, 0);
				answer = mxmlNewElement(question, "answer");
				mxmlElementSetAttr(answer, "fraction", "100");
				mxmlElementSetAttr(answer, "format", "moodle_auto_format");
				text = mxmlNewElement(answer, "text");
				value = mxmlNewReal(text, naq.ans);
				genfd = mxmlNewElement(answer, "feedback");
				mxmlElementSetAttr(genfd, "format", "html");
				text = mxmlNewElement(genfd, "text");
				genfd = mxmlNewElement(answer, "tolerance");
				value = mxmlNewInteger(genfd, 0);
				genfd = mxmlNewElement(question, "unitgradingtype");
				value = mxmlNewInteger(genfd, 0);
				genfd = mxmlNewElement(question, "unitpenalty");
				value = mxmlNewReal(genfd, 0.1000000);
				genfd = mxmlNewElement(question, "showunits");
				value = mxmlNewInteger(genfd, 3);
				genfd = mxmlNewElement(question, "unitsleft");
				value = mxmlNewInteger(genfd, 0);
				break;
			case _MTP:
				questiontext = mxmlNewElement(question, "questiontext");
				mxmlElementSetAttr(questiontext, "format", "html");
				text = mxmlNewElement(questiontext, "text");
				value = mxmlNewText(text, 0, "match the pairs");
				genfd = mxmlNewElement(question, "generalfeedback");
				mxmlElementSetAttr(genfd, "format", "html");
				text = mxmlNewElement(genfd, "text");
				genfd = mxmlNewElement(question, "defaultgrade");
				value = mxmlNewReal(genfd, 1.0);
				genfd = mxmlNewElement(question, "penalty");
				value = mxmlNewReal(genfd, (double)1/3);
				genfd = mxmlNewElement(question, "hidden");
				value = mxmlNewInteger(genfd, 0);
				genfd = mxmlNewElement(question, "shuffleanswers");
				value = mxmlNewText(genfd, 0, "true");
				genfd = mxmlNewElement(question, "correctfeedback");
				mxmlElementSetAttr(genfd, "format", "html");
				text = mxmlNewElement(genfd, "text");
				value = mxmlNewText(text, 0, "Your answer is Correct.");
				genfd = mxmlNewElement(question, "partiallycorrectfeedback");
				mxmlElementSetAttr(genfd, "format", "html");
				text = mxmlNewElement(genfd, "text");
				value = mxmlNewText(text, 0, "Your answer is partially correct.");
				genfd = mxmlNewElement(question, "incorrectfeedback");
				mxmlElementSetAttr(genfd, "format", "html");
				text = mxmlNewElement(genfd, "text");
				value = mxmlNewText(text, 0, "Your answer is Incorrect.");
				genfd = mxmlNewElement(question, "shownumcorrect");
				
				
				fread(&i, sizeof(int), 1,fp);
				p = (pair*) malloc(sizeof(pair));

				if(p == NULL) {printf("Memory not allocated");}
				for(j = 0; j < i; j++) {
					fread(p, sizeof(pair), 1, fp);
					genfd = mxmlNewElement(question, "subquestion");
					mxmlElementSetAttr(genfd, "format", "html");
					text = mxmlNewElement(genfd, "text");
					value = mxmlNewCDATA(text, p->str1);
					answer = mxmlNewElement(genfd, "answer");
					text = mxmlNewElement(answer, "text");
					value = mxmlNewCDATA(text, p->str2);
								
				}
				free(p);
				break;
		}
		
	}
	fclose(fp);
	printf("Enter a name for xml file:");
	scanf("%s", filename);
	getchar();
	strcpy(temp, "./Export_Files/");/*./QuestionBank/filename.qb*/
	strcat(temp, filename);
	strcat(temp, ".xml");
	fp = fopen(temp, "w");
	if(!fp) {
		perror("Cant open file ");
		getchar();
		return;
	}
	mxmlSaveFile(xml, fp, MXML_NO_CALLBACK);
	printf("\nData exported successfully.........\n");
	fclose(fp);
	mxmlDelete(xml);/*Delete the tree*/
}

char* getfilenameimport(char* str) {
	char* filename, *temp;
	int i, len;
	for(i = strlen(str) - 1; i >= 0; i--) {
		if(str[i] == '/') {
			break;	
		}
	}
	i++;
	temp = &str[i];
	len = strlen(temp);
	filename = (char*)malloc(sizeof(char) * (len + 1));
	strcpy(filename, temp);
	return filename;
}

int getTypeFromString(char* type, char* single) {
	printf("Inside get Type func\n");
	if(!strcmp(type, "multichoice")) {
		if(!strcmp(single, "true"))
			return _MCQ;
		else
			return _MAQ;
	}
	else if(!strcmp(type, "numerical"))
		return _NAQ;
	else if(!strcmp(type, "matching"))
		return _MTP;
	return -1;		
}

char* removeCDATA(const char* str) {
	char* temp = malloc((strlen(str) + 1) * sizeof(char));
	strcpy(temp, str);
	temp[strlen(str) - 2] = '\0';
	return temp;
}
void import2(char* filename) {/*Assume .xml extension*/
	char tempstr[100], str[100], type[20], *file , ans, *ansstr;
	const char *frac, *single;
	double fracvalue;
	int i = 0, j = 0, k, t;
	FILE* fp;
	mxml_node_t *tree;
	mxml_node_t *node, *quiz, *temp, *question, *answer, *temp2;
	questionString qs;
	NAQ naq;
	pair pairs;
	 printf("In the function\n");
	if(filename[0] != '/') {
		strcpy(tempstr, "./");
		strcat(tempstr, filename);
    	}
	else {
		strcpy(tempstr, filename);
	}
	fp = fopen(tempstr, "r");
	if(!fp) {
		perror("Cant open file ");
		getchar();
		return;
	}
	printf("File opened \n");
	tree = mxmlLoadFile(NULL, fp, MXML_TEXT_CALLBACK);/*Fetching the whole tree*/
	fclose(fp);
	
	if(!tree) {
		errno = EINVAL;
		perror("Not an XML file");
		return;
	}

	//printf("\nEnter a name for this new Question Bank:\n");
	//scanf("%s", filename);
	quiz = tree->child;//quiz tag
	if(!quiz) {
		perror("While parsing <quiz>tag not  found");
		getchar();
		return;
	}
/*
	node = mxmlFindElement (quiz, tree, "question", "type", "category", MXML_DESCEND_FIRST);
	if(!node) {
		perror("While parsing No <question> with category attribute  found");
		getchar();
		return;
	}
	printf("category : %s\n", node->child->child->child->value.text.string);
	file = getfilenameimport(node->child->child->child->value.text.string);*/

	strcpy(str, "abc"/*file*/);/*name of qb*/
	strcpy(tempstr, "./QuestionBank/");
	strcat(tempstr, str);
	/*free(file);*/
	strcat(tempstr, ".qb");
	fp = fopen(tempstr , "w");
	if(!fp) {
		perror("Cant open file ");
		getchar();
		return;
	}
	j = 0;
	printf("Number of questions: %d\n", j);
	fwrite(&j, sizeof(int), 1, fp);/*no of ques*/
	i = 0;
	for(node = mxmlFindElement(quiz, tree, "question", "type", NULL, MXML_DESCEND_FIRST); node != NULL; node = mxmlGetNextSibling(node), i++) {/*node is question tag*/
		strcpy(type, mxmlElementGetAttr(node, "type"));
		if(!type) {
			perror("While parsing  no type attribute  found");
			getchar();
			return;
		}

		printf("Type %s\n", type);
		if(!strcmp(type, "category")){
			i--;
			continue;
		}
		j = i + 1;
		temp = mxmlFindElement(node, tree, "single", NULL, NULL, MXML_DESCEND_FIRST);
		if(!temp) {
			printf("There is no single attribute\n");
			t = getTypeFromString(type, NULL);
		}
		else {
		
			t = getTypeFromString(type, temp->child->value.text.string);
		}
		
			printf("Outside type\n");
		if(t == -1) {
			perror("Wrong type of question soignored");
			i--;
			getchar();
			continue;
		}
		printf("ID : %d\n", j);
		fwrite(&j, sizeof(int), 1, fp);/*ID*/
		printf("Type: %d\n", t);
		fwrite(&t, sizeof(int), 1, fp);/*type*/
		switch(t) {
			case _MCQ: 
				temp = mxmlFindElement(node, tree, "questiontext", NULL, NULL, MXML_DESCEND_FIRST);
				if(!temp) {
					perror("While parsing  no <questiontext> tag found");
					getchar();
					return;
				}
				temp = temp->child;/*text tag*/
				if(!temp) {
					perror("While parsing  no <text> inside <questiontext> tag found");
					getchar();
					return;
				}
				strcpy(qs.ques, removeCDATA(mxmlGetCDATA(temp->child)));/*Questiontext*/
				printf("Question text %s\n",qs.ques);
				fwrite(&qs,sizeof(struct questionString), 1, fp);/*Storing questionString structure*/
				j = 0;
				for(answer = mxmlFindElement(node, tree, "answer", NULL, NULL, MXML_DESCEND_FIRST); answer != NULL; answer = mxmlGetNextSibling(answer)) {
					j++;
				}
				printf("No of options : %d\n", j);
		
				fwrite(&j, sizeof(int), 1, fp);/*no of options*/
				j = 0;
				for(answer = mxmlFindElement(node, tree, "answer", NULL, NULL, MXML_DESCEND_FIRST); answer != NULL; answer = mxmlGetNextSibling(answer)) {
					temp =  mxmlFindElement(answer, tree, "text", NULL, NULL, MXML_DESCEND_FIRST);/*text tag*/
					if(!temp) {
						perror("While parsing  no <text> inside <answer> tag found");
						getchar();
						return;
					}
					printf("option :%s\n", mxmlGetCDATA(temp->child));
					fwrite(removeCDATA(mxmlGetCDATA(temp->child)), sizeof(char) * 20, 1, fp);/*Storing options*/
					frac = mxmlElementGetAttr(answer, "fraction");
					if(!strcmp(frac, "100")) {
						ans = (char)'A' + j;
					}	
					j++;
								
				}
				printf("Correct ans is %c\n",ans);
				fwrite(&ans, sizeof(char), 1, fp);
				break;
			case _MAQ:
				temp = mxmlFindElement(node, tree, "questiontext", NULL, NULL, MXML_DESCEND_FIRST);
				if(!temp) {
					perror("While parsing  no <questiontext> tag found");
					getchar();
					return;
				}
				temp = temp->child;/*text tag*/
				if(!temp) {
					perror("While parsing  no <text> inside <questiontext> tag found");
					getchar();
					return;
				}
				strcpy(qs.ques, removeCDATA(mxmlGetCDATA(temp)));/*Questiontext*/
				printf("Question text %s\n",qs.ques);
			
				fwrite(&qs,sizeof(struct questionString), 1, fp);/*Storing questionString structure*/
				j = 0;
				for(answer = mxmlFindElement(node, tree, "answer", NULL, NULL, MXML_DESCEND_FIRST); answer != NULL; answer = mxmlGetNextSibling(answer)) {
					j++;
				}
				printf("No of options : %d\n", j );
				
				fwrite(&j, sizeof(int), 1, fp);/*no of options*/
				ansstr = (char*)malloc(sizeof(char) * (j + 1));
				j = 0;
				k = 0;
				for(answer = mxmlFindElement(node, tree, "answer", NULL, NULL, MXML_DESCEND_FIRST); answer != NULL; answer = mxmlGetNextSibling(answer)) {
					temp =  mxmlFindElement(answer, tree, "text", NULL, NULL, MXML_DESCEND_FIRST);/*text tag*/
					if(!temp) {
						perror("While parsing  no <text> inside <answer> tag found");
						getchar();
						return;
					}
					fwrite(removeCDATA(mxmlGetCDATA(temp->child)), sizeof(char) * 20, 1, fp);/*Storing options*/
					frac = mxmlElementGetAttr(answer, "fraction");
					fracvalue = atof(frac);
					if(fracvalue > 0) {
						 ansstr[k] = (char)'A' + j;
						k++;
					}	
					j++;
								
				}
				ansstr[k] = '\0';
				printf("Answer for multiple answer %s \n", ansstr);
				/////////////here////////////////////////////////////////////////////
				fwrite(ansstr, sizeof(char), strlen(ansstr) + 1, fp);/*storing string with \0*/
				free(ansstr);
				break;
			case _NAQ:
				temp = mxmlFindElement(node, tree, "questiontext", NULL, NULL, MXML_DESCEND_FIRST);
				if(!temp) {
					perror("While parsing  no <questiontext> tag found");
					getchar();
					return;
				}
				temp = temp->child;/*text tag*/
				if(!temp) {
					perror("While parsing  no <text> inside <questiontext> tag found");
					getchar();
					return;
				}
				strcpy(qs.ques, removeCDATA(mxmlGetCDATA(temp->child)));/*Questiontext*/
				printf("question naq: %s", qs.ques);
				naq.qs = qs;
				answer = mxmlFindElement(node, tree, "answer", "fraction", "100", MXML_DESCEND_FIRST);
				if(!answer) {
					perror("While parsing  no <answer> tag found for naq");
					getchar();
					return;
				}
				answer = mxmlFindElement(answer, tree, "text", NULL, NULL, MXML_DESCEND_FIRST);
				if(!answer) {
					perror("While parsing  no <text> tag inside <answer> found for naq");
					getchar();
					return;
				}
				strcpy(tempstr, answer->child->value.text.string);
				printf("Answer of naq: %s\n", tempstr);
				naq.ans = atof(tempstr);/*answer tag*/
				fwrite(&naq, sizeof(NAQ), 1, fp);/*Storing NAQ structure*/
				break;
			case _MTP:
				j = 0;
				for(answer = mxmlFindElement(node, tree, "subquestion", NULL, NULL, MXML_DESCEND_FIRST); answer != NULL; answer = mxmlGetNextSibling(answer)) {
					j++;
				}
				
				printf("There are %d many pairs\n", j);
				
				
				fwrite(&(j), sizeof(int), 1, fp);/*No of pairs tag*/
				
			
				for(answer = mxmlFindElement(node, tree, "subquestion", NULL, NULL, MXML_DESCEND_FIRST); answer != NULL; answer = mxmlGetNextSibling(answer)) {
					temp =  mxmlFindElement(answer, tree, "text", NULL, NULL, MXML_DESCEND_FIRST);/*ques tag*/
					if(!temp) {
						perror("While parsing  no <text> inside <subquestion> tag found");
						getchar();
						return;
					}
					strcpy(pairs.str1, removeCDATA(mxmlGetCDATA(temp->child)));
					
					temp2 =  mxmlFindElement(answer, tree, "answer", NULL, NULL, MXML_DESCEND_FIRST);/*ans tag*/
					if(!node) {
						perror("While parsing  no <answer> inside <subquestion> tag found");
						getchar();
						return;
					}
					strcpy(pairs.str2, removeCDATA(mxmlGetCDATA(temp2->child->child)));
					fwrite(&pairs, sizeof(pair), 1, fp);
					printf("%s ---  %s\n", pairs.str1, pairs.str2);				
				}
				break;
						
		}
		
		
		
	}
	fseek(fp, 0,SEEK_SET);
	printf("Total questions: %d\n", i);
	fwrite(&i, sizeof(int), 1, fp);
	printf("\nDATA imported\n");
	getchar();
	getchar();
	fclose(fp);
	mxmlDelete(tree);
}
