char* convertintoString(int a){
	if(_MCQ || _MAQ)
		return "multichoice";
	else
		return NULL;
}

int found(int* arr, int n, int find){
	int i;
	for(i = 0; i < n; i++) {
		if(arr[i] == find)
			return 1;
	}
	return 0;
}
void export2(char* filename) {
	char temp[100], idstr[6], **optionstr, str[20], correctfrac[20], incorrectfrac[20];
	int anslen, *arr;
	pair* p;
	int id;
	int i, j, k = 0, mark = 0, ans;
	questionString qs;
	NAQ naq;
	char str[20], ch;
	FILE* fp;
	mxml_node_t *xml, *quiz, *value, *question, *category, *name, *questiontext, *text, *genfd, *answer, *no_of_pairs, *pairN, *ques;
	strcpy(temp, "./QuestionBank/");/*./QuestionBank/filename.qb*/
	strcat(temp, filename);
	strcat(temp, ".qb");
	fp = fopen(temp, "r");
	//printf("%s\n", file_name);
	
	if(!fp) {
		perror("Cant open file ");
		getchar();
		return;
	}
	xml = mxmlNewXML("1.0");//Xml tag
	quiz = mxmlNewElement(xml, "quiz");/*questionbank*/
	//mxmlElementSetAttr(questionbank, "name", filename);/*name attr*/
	fread(&i, sizeof(int), 1, fp);/*READ no of ques*/
	question = mxmlNewElement(quiz, "question");
	mxmlElementSetAttr(question, "type", "category");
	category = mxmlNewElement(question, "category");
	text = mxmlNewElement(category, "text");
	value = mxmlNewText(text, 0, filename);
	//no_of_ques = mxmlNewElement(questionbank, "no_of_ques");
	//value = mxmlNewInteger(no_of_ques, i);/*no of ques*/
	
	while(fread(&id, sizeof(int), 1, fp) != 0) {/*READ question ID*/
		question = mxmlNewElement(quiz,"question");/*question tag*/
		fread(&i, sizeof(int), 1, fp);/*READ ques type*/
		mxmlElementSetAttr(question, "type", convertintoString(i));
		name = mxmlNewElement(question, "name");
		text = mxmlNewElement(name, "text");
		sprintf(idstr, "%d", id);
		strcpy(temp, "Question : ");
		strcat(temp, idstr);
		value = mxmlNewText(text, 0, temp);

		switch(i) {
			case _MCQ: 
				fread(&qs,sizeof(struct questionString), 1, fp);/*Storing questionString structure*/
				questiontext = mxmlNewElement(question, "questiontext");
				text = mxmlNewElement(questiontext, "text");
				value = mxmlNewText(text, 0, qs.ques);
				genfd = mxmlNewElement(question, "generalfeedback");
				mxmlElementSetAttr(genfd, "format", "html");
				text = mxmlNewElement(genfd, "text");
				genfd = mxmlNewElement(question, "defaultgrade");
				value = mxmlNewReal(genfd, 1.0);
				genfd = mxmlNewElement(question, "penalty");
				value = mxmlNewReal(genfd, (double)1/3);
				genfd = mxmlNewElement(question, "hidden");
				value = mxmlNewInteger(genfd, 0);
				genfd = mxmlNewElement(question, "single");
				value = mxmlNewText(genfd, 0, "true");
				genfd = mxmlNewElement(question, "shuffleanswers");
				value = mxmlNewText(genfd, 0, "true");
				genfd = mxmlNewElement(question, "answernumbering");
				value = mxmlNewText(genfd, 0, "abc");
				genfd = mxmlNewElement(question, "correctfeedback");
				mxmlElementSetAttr(genfd, "format", "html");
				text = mxmlNewElement(genfd, "text");
				value = mxmlNewText(text, 0, "Your answer is Correct.");
				genfd = mxmlNewElement(question, "partiallycorrectfeedback");
				mxmlElementSetAttr(genfd, "format", "html");
				text = mxmlNewElement(genfd, "text");
				genfd = mxmlNewElement(question, "incorrectfeedback");
				mxmlElementSetAttr(genfd, "format", "html");
				text = mxmlNewElement(genfd, "text");
				value = mxmlNewText(text, 0, "Your answer is Incorrect.");

				fread(&i, sizeof(int), 1, fp);/*no of options*/
				optionstr = (char**)malloc(sizeof(char*) * i);
				for(j = 0; j < i; j++) {
					optionstr[j] = (char*)malloc(sizeof(char) * 20);
				}
				j = 0;
				while(j < i) {

					fread(optionstr[j], sizeof(char) , 20, fp);/*Reading options*/
					j++;
							
				}
				fread(&ch, sizeof(char), 1, fp);
				ans = (int) ch - 'A';
				j = 0;
				while(j < i) {

					answer = mxmlNewElement(question, "answer");
					mxmlElementSetAttr(answer, "format", "html");
					if(j == ans) {
						mxmlElementSetAttr(answer, "fraction", "100");
					}
					else {
						mxmlElementSetAttr(answer, "fraction", "0");
					}
					text = mxmlNewElement(answer, "text");
					value = mxmlNewText(text, 0, optionstr[j]);
					genfd = mxmlNewElement(answer, "feedback");
					mxmlElementSetAttr(genfd, "format", "html");
					text = mxmlNewElement(genfd, "text");
					j++;
							
				}
				for(j = 0; j < i; j++) {
					free(optionstr[j]);
				}
				break;
			case _MAQ: 
				fread(&qs,sizeof(struct questionString), 1, fp);/*Storing questionString structure*/
				questiontext = mxmlNewElement(question, "questiontext");
				text = mxmlNewElement(questiontext, "text");
				value = mxmlNewText(text, 0, qs.ques);
				genfd = mxmlNewElement(question, "generalfeedback");
				mxmlElementSetAttr(genfd, "format", "html");
				text = mxmlNewElement(genfd, "text");
				genfd = mxmlNewElement(question, "defaultgrade");
				value = mxmlNewReal(genfd, 1.0);
				genfd = mxmlNewElement(question, "penalty");
				value = mxmlNewReal(genfd, (double)1/3);
				genfd = mxmlNewElement(question, "hidden");
				value = mxmlNewInteger(genfd, 0);
				genfd = mxmlNewElement(question, "single");
				value = mxmlNewText(genfd, 0, "false");
				genfd = mxmlNewElement(question, "shuffleanswers");
				value = mxmlNewText(genfd, 0, "true");
				genfd = mxmlNewElement(question, "answernumbering");
				value = mxmlNewText(genfd, 0, "abc");
				genfd = mxmlNewElement(question, "correctfeedback");
				mxmlElementSetAttr(genfd, "format", "html");
				text = mxmlNewElement(genfd, "text");
				value = mxmlNewText(text, 0, "Your answer is Correct.");
				genfd = mxmlNewElement(question, "partiallycorrectfeedback");
				mxmlElementSetAttr(genfd, "format", "html");
				text = mxmlNewElement(genfd, "text");
				genfd = mxmlNewElement(question, "incorrectfeedback");
				mxmlElementSetAttr(genfd, "format", "html");
				text = mxmlNewElement(genfd, "text");
				value = mxmlNewText(text, 0, "Your answer is Incorrect.");

				fread(&i, sizeof(int), 1, fp);/*no of options*/
				optionstr = (char**)malloc(sizeof(char*) * i);
				for(j = 0; j < i; j++) {
					optionstr[j] = (char*)malloc(sizeof(char) * 20);
				}
				j = 0;
				while(j < i) {

					fread(optionstr[j], sizeof(char) , 20, fp);/*Reading options*/
					j++;
							
				}
				arr = (int*) malloc(sizeof(int) * i);
				
				j = 0;
				do {
					fread(&ch, sizeof(char), 1, fp);/*reading ans till '\0'*/
					str[j] = ch;
					arr[j] = ch - 'A';
					j++;
				}while(ch != '\0');
				anslen = strlen(str);
				sprintf(correctfrac, "%.2f", ((float)1/anslen) * 100);
				if(i != anslen)
					sprintf(incorrectfrac, "%.2f", ((float)1/(i - anslen)) * 100);
				else
					sprintf(incorrectfrac, "%.2f", 0);
				j = 0;
				while(j < i) {

					answer = mxmlNewElement(question, "answer");
					mxmlElementSetAttr(answer, "format", "html");
					if(found(arr, anslen, j) == 1) {
						mxmlElementSetAttr(answer, "fraction", correctfrac);
					}
					else {
						mxmlElementSetAttr(answer, "fraction", incorrectfrac);
					}
					text = mxmlNewElement(answer, "text");
					value = mxmlNewText(text, 0, optionstr[j]);
					genfd = mxmlNewElement(answer, "feedback");
					mxmlElementSetAttr(genfd, "format", "html");
					text = mxmlNewElement(genfd, "text");
					j++;
							
				}
				
				break;
				
		}
		
		//fread(&mark, sizeof(int), 1, fp);
		//marks = mxmlNewElement(question, "marks");
		//value = mxmlNewInteger(marks, 0);
		
	}
	fclose(fp);
	printf("Enter a name for xml file:");
	scanf("%s", filename);
	getchar();
	strcpy(temp, "./Export_Files/");/*./QuestionBank/filename.qb*/
	strcat(temp, filename);
	strcat(temp, ".xml");
	fp = fopen(temp, "w");
	if(!fp) {
		perror("Cant open file ");
		getchar();
		return;
	}
	mxmlSaveFile(xml, fp, MXML_NO_CALLBACK);
	printf("\nData exported successfully.........\n");
	fclose(fp);
	mxmlDelete(xml);/*Delete the tree*/
}
