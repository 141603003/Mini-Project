
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include<dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include "print.h"
int maxwidth;
int filefound;
char filenames[100][20];
/*creates question bank directory if not available*/
void initialization() {
	int foundqb = 0, foundqz = 0, foundinfo = 0;/*boolean for found*/
	DIR *dp = NULL;
    	struct dirent *dptr = NULL;
	if((dp = opendir("./")) == NULL) {
		printf("\n No access to current directoy");
		exit(1);
   	}
	while((dptr = readdir(dp)) != NULL ) {
		//printf("%s\n", dptr->d_name);
   		if((foundqb == 0) && (!strcmp("QuestionBank", dptr->d_name)) ) {
			foundqb = 1;
		}
		if((foundqz == 0) && (!strcmp("Quiz", dptr->d_name)) ) {
			foundqz = 1;
		}
		if((foundinfo == 0) && (!strcmp("Info", dptr->d_name)) ) {
			foundinfo = 1;
		}
		
        }
	closedir(dp);
	if(!foundqb) {
		mkdir("QuestionBank",S_IRWXU|S_IRWXG|S_IRWXO);
	}
	if(!foundqz) {
		mkdir("Quiz",S_IRWXU|S_IRWXG|S_IRWXO);
	}
	if(!foundinfo) {
		mkdir("Info",S_IRWXU|S_IRWXG|S_IRWXO);
	}
	
}
void printheader(char* str) {
	int i, pos;
	system("clear");
	for(i = 0; i < maxwidth; i++)
		printf("=");
	printf("\n\n");
	pos = maxwidth / 2 - (strlen(str) / 2);
	for(i = 0; i < pos; i++) 
		printf(" ");
	printf("%s\n\n", str);
	for(i = 0; i < maxwidth; i++)
		printf("=");
	printf("\n");
	
	
}
void initial() {
	maxwidth = 1366 / 10;
	printheader("Welcome to Quizzy");
	printmiddle("Press ENTER to continue.......");
	printmiddle("Press ESC <ENTER> to exit.............");
}
void printmiddle(char* str) {
	int i, pos;
	pos = maxwidth / 2 - (strlen(str) / 2);
	for(i = 0; i < pos; i++) 
		printf(" ");
	printf("%s\n", str);
}

int loginprint() {
	char choice;
	system("clear");
	printheader("Quizzy");
	printmiddle("LOGIN PAGE");
	printmiddle("(Press ESC to exit any time)");
	printf("Select the type of Login :\n");
	printf("\n%-10s%20s\n", "1. ADMIN", "[1]");
	printf("%-10s%20s\n\n", "2. STUDENT", "[2]");
	printf("Please Enter your choice code : ");
	scanf("%c", &choice);
	getchar();/*to remove enter*/
	if(choice == 27) {
		system("clear");
		exit(0);
	}
	else
		return (int)(choice - '0');
	
}

void validator() {
	int i = 0;
	char str[100];
	getchar();
	printf("Enter Admin password :\n");
	while(i < 3) {
		scanf("%s", str);
		getchar();/*for enter*/
		if(!strcmp("1234", str))
			return;
		else {
			printf("Wrong password\n");
			if(i == 1)
				printf("Last attempt:\n");
				
		}
		i++;
	}
	printf("Are you intruder?\n");
	getchar();
	system("clear");
	exit(1);
}

void validation(int l) {
	FILE* fp = NULL;
	char mis[20];
	if(l == STUDENT) {
		
		printf("Enter your MISID : ");
		scanf("%s", mis);
		getchar();
		fp = fopen(mis,"a");
		if(!fp) {
			printf("Problem with file");
			exit(1);
		}
		fclose(fp);
	}
}
int printmenu(int l) {
	char choice;
	
	system("clear");
	if(l == ADMIN) {
		printheader("Quizzy");
		printmiddle("ADMIN");
		printf("\n%-40s%5s\n","1. Create NEW Question Bank", "[1]");
		printf("%-40s%5s\n","2. View Available Question Bank", "[2]");
		printf("%-40s%5s\n","3. Create NEW Quiz", "[3]");
		printf("%-40s%5s\n","4. View Available Quiz", "[4]");
		printf("%-40s%5s\n","5. Export a QuestionBank", "[5]");
		printf("%-40s%5s\n\n","6. Import a QuestionBank", "[6]");
		printf("Enter your choice:");
		scanf("%c", &choice);
		printf("got %c\n", choice);
		getchar();
		if(choice == 27) {
			system("clear");
			exit(0);
		}
		else
			return (int)(choice - '0');
	}
	else if(l == STUDENT) {
		printheader("Quizzy");
		printmiddle("STUDENT");
		printf("\n%-40s%5s\n","1. Run a Quiz", "[1]");
		printf("%-40s%5s\n\n","2. View Pending Quiz", "[2]");
		printf("Enter your choice:");
		scanf("%c", &choice);
		getchar();
		if(choice == 27) {
			system("clear");
			exit(0);
		}
		else
			return (int)((choice - '0') + 7);
	}
}
void availablefilename(char* dirname, char* filetype){
	DIR *dp = NULL;
	
	int cmp, lenofext;
    	struct dirent *dptr = NULL;
	int len,i = 1;
	char *last_three;
	filefound = 0;
	lenofext = strlen(filetype);
	cmp = strcmp(filetype, ".qb");/*Compares with .qb 0->qb 1->quiz*/
	if(cmp == 0)
		printf("Available Question Banks in current directory: \n");
	else
		printf("Available Quiz Sets in current directory: \n");
		
	if((dp = opendir(dirname)) == NULL) {
		printf("\n No access of current directoy");
		getchar();
		return ;
   	}
	while((dptr = readdir(dp)) != NULL ) {
		len = strlen(dptr->d_name);
		if(len > lenofext){
			last_three = &dptr->d_name[len - lenofext];
			if(!strcmp(last_three, filetype)) {
				strcpy(filenames[i - 1], dptr->d_name); 
				printf("%d. %s\n", i, dptr->d_name);
				printf("%d. %s\n", i, filenames[i - 1]);
   				++i;
				filefound++;
			}
		}
        }
	if(i == 1) {
		if(cmp == 0)
			printf("No Question Bank available yet........\n");
		else
			printf("No Quiz Sets available yet........\n");
	}
	printf("\n(Press Enter key)\n");
	getchar();
	closedir(dp);
	
}

char* getfilename(char* dirname, char* filetype) {
	char file[100], *temp, **filenames;
	int fileindex = 0;
	availablefilename(dirname, filetype);
	if(filefound != 0) {
		printf("Enter your choice from above (1 - %d)\n", filefound);		
		scanf("%d", &fileindex);
		getchar();
		
		if(fileindex < 0 && fileindex > filefound) {
				printf("Wrong input\n");
				return NULL;
		}
		
		printf("%s", filenames[0]);
		getchar();
		strcpy(file, filenames[fileindex - 1]);
	/*	strcat(file, filetype);
		strcpy(file, strcat(dir, file));*/
		temp = (char*) malloc(sizeof(char) * strlen(file) + 1);
		strcpy(temp, file);
		return temp;
	}
	else 
		return NULL;
		
}
