char* getfilename(char* str) {
	char* filename, *temp;
	int i, len;
	for(i = strlen(str) - 1; i >= 0; i--) {
		if(str[i] == '/') {
			break;	
		}
	}
	i++;
	temp = &str[i];
	len = strlen(temp);
	filename = (char*)malloc(sizeof(char) * (len + 1));
	strcpy(filename, temp);
	return filename;
}

int getTypeFromString(char* type,char* single) {
	if(!strcmp(type, "multichoice")) {
		if(!strcmp(single, "true"))
			return _MCQ;
		else
			return _MAQ;
	}
	else if(!strcmp(type, "numerical"))
		return _NAQ;
	else if(!strcmp(type, "matching"))
		return _MTP;
	return -1;		
}
void import2(char* filename) {/*Assume .xml extension*/
	char tempstr[100], str[100], type[20], *single, *file, ans, *frac, *ansstr;
	double fracvalue;
	int i = 0, j = 0, k, t;
	FILE* fp;
	mxml_node_t *tree;
	mxml_node_t *node, *quiz, *temp, *question, *answer;
	questionString qs;
	NAQ naq;
	pair pairs;
	 
	if(filename[0] != '/') {
		strcpy(temp, "./");
		strcat(temp, filename);
    	}
	else {
		strcpy(temp, filename);
	}
	fp = fopen(temp, "r");
	if(!fp) {
		perror("Cant open file ");
		getchar();
		return;
	}
	tree = mxmlLoadFile(NULL, fp, MXML_TEXT_CALLBACK);/*Fetching the whole tree*/
	fclose(fp);
	
	if(!tree) {
		errno = EINVAL;
		perror("Not an XML file");
		return;
	}

	//printf("\nEnter a name for this new Question Bank:\n");
	//scanf("%s", filename);
	quiz = tree->child;//quiz tag
	if(!quiz) {
		perror("While parsing <quiz>tag no name attribute found");
		getchar();
		return;
	}

	node = mxmlFindElement (quiz, tree, "question", "type", "category", MXML_DESCEND_FIRST);
	if(!node) {
		perror("While parsing No <question> with category attribute  found");
		getchar();
		return;
	}
	file = getfilename(node->child->child->value.text.string);
	printf("category : %s\n", node->child->child->value.text.string);
	strcpy(str, file);/*name of qb*/
	strcpy(tempstr, "./QuestionBank/");
	strcat(tempstr, str);
	free(file);
	strcat(tempstr, ".qb");
	fp = fopen(tempstr , "r+w");
	if(!fp) {
		perror("Cant open file ");
		getchar();
		return;
	}
	fwrite(0, sizeof(int), 1, fp);/*no of ques*/
	i = 0;
	for(node = mxmlFindElement(quiz, tree, "question", "type", NULL, MXML_DESCEND_FIRST); node != NULL; node = mxmlGetNextSibling(node), i++) {/*node is question tag*/
		strcpy(type, mxmlElementGetAttr(node, "type"));
		if(!type) {
			perror("While parsing  no type attribute  found");
			getchar();
			return;
		}

		printf("Type %s\n", type);
		if(!strcmp(type, "category")){
			i--;
			continue;
		}
		j = i + 1;
		single = mxmlFindElement(node, tree, "single", NULL, NULL, MXML_DESCEND_FIRST);
		if(!single) {
			printf("There is no single attribute\n");
		}
		t = getTypeFromString(type, single);
		if(t == -1) {
			perror("Wrong type of question soignored");
			i--;
			getchar();
			continue;
		}
		fwrite(&j, sizeof(int), 1, fp);/*ID*/
		fwrite(&t, sizeof(int), 1, fp);/*type*/
		switch(t) {
			case _MCQ: 
				temp = mxmlFindElement(node, tree, "questiontext", NULL, NULL, MXML_DESCEND_FIRST);
				if(!temp) {
					perror("While parsing  no <questiontext> tag found");
					getchar();
					return;
				}
				temp = temp->child;/*text tag*/
				if(!temp) {
					perror("While parsing  no <text> inside <questiontext> tag found");
					getchar();
					return;
				}
				strcpy(qs.ques, temp->child->value.text.string);/*Questiontext*/
				fwrite(&qs,sizeof(struct questionString), 1, fp);/*Storing questionString structure*/
				j = 0;
				for(answer = mxmlFindElement(node, tree, "answer", NULL, NULL, MXML_DESCEND_FIRST); answer != NULL; answer = mxmlGetNextSibling(answer)) {
					j++;
				}
				printf("No of options : %d\n", j - 1);
				--j;
				fwrite(&j, sizeof(int), 1, fp);/*no of options*/
				j = 0;
				for(answer = mxmlFindElement(node, tree, "answer", NULL, NULL, MXML_DESCEND_FIRST); answer != NULL; answer = mxmlGetNextSibling(answer)) {
					temp =  mxmlFindElement(answer, tree, "text", NULL, NULL, MXML_DESCEND_FIRST);/*text tag*/
					if(!temp) {
						perror("While parsing  no <text> inside <answer> tag found");
						getchar();
						return;
					}
					fwrite(temp->child->value.text.string, sizeof(char) * 20, 1, fp);/*Storing options*/
					frac = mxmlElementGetAttr(answer, "fraction");
					if(!strcmp(frac, "100")) {
						ans = (char)'A' + j;
					}	
					j++;
								
				}
			
				fwrite(&ans, sizeof(char), 1, fp);
				break;
			case _MAQ:
				temp = mxmlFindElement(node, tree, "questiontext", NULL, NULL, MXML_DESCEND_FIRST);
				if(!temp) {
					perror("While parsing  no <questiontext> tag found");
					getchar();
					return;
				}
				temp = temp->child;/*text tag*/
				if(!temp) {
					perror("While parsing  no <text> inside <questiontext> tag found");
					getchar();
					return;
				}
				strcpy(qs.ques, temp->child->value.text.string);/*Questiontext*/
				fwrite(&qs,sizeof(struct questionString), 1, fp);/*Storing questionString structure*/
				j = 0;
				for(answer = mxmlFindElement(node, tree, "answer", NULL, NULL, MXML_DESCEND_FIRST); answer != NULL; answer = mxmlGetNextSibling(answer)) {
					j++;
				}
				printf("No of options : %d\n", j - 1);
				--j;
				fwrite(&j, sizeof(int), 1, fp);/*no of options*/
				ansstr = (char*)malloc(sizeof(char) * (j + 1));
				j = 0;
				k = 0;
				for(answer = mxmlFindElement(node, tree, "answer", NULL, NULL, MXML_DESCEND_FIRST); answer != NULL; answer = mxmlGetNextSibling(answer)) {
					temp =  mxmlFindElement(answer, tree, "text", NULL, NULL, MXML_DESCEND_FIRST);/*text tag*/
					if(!temp) {
						perror("While parsing  no <text> inside <answer> tag found");
						getchar();
						return;
					}
					fwrite(temp->child->value.text.string, sizeof(char) * 20, 1, fp);/*Storing options*/
					frac = mxmlElementGetAttr(answer, "fraction");
					fracvalue = atof(frac);
					if(frac > 0) {
						 ansstr[k] = (char)'A' + j;
						k++;
					}	
					j++;
								
				}
				ansstr[k] = '\0';
				printf("Answer for multiple answer %s \n", ansstr);
				/////////////here////////////////////////////////////////////////////
				fwrite(ansstr, sizeof(char), strlen(ansstr) + 1, fp);/*storing string with \0*/
				free(ansstr);
				break;
			case _NAQ:
				temp = mxmlFindElement(node, tree, "questiontext", NULL, NULL, MXML_DESCEND_FIRST);
				if(!temp) {
					perror("While parsing  no <questiontext> tag found");
					getchar();
					return;
				}
				temp = temp->child;/*text tag*/
				if(!temp) {
					perror("While parsing  no <text> inside <questiontext> tag found");
					getchar();
					return;
				}
				strcpy(qs.ques, temp->child->value.text.string);/*Questiontext*/
				printf("question naq: %s", temp->child->value.text.string);
				naq.qs = qs;
				answer = mxmlFindElement(node, tree, "answer", "fraction", "100", MXML_DESCEND_FIRST);
				if(!answer) {
					perror("While parsing  no <answer> tag found for naq");
					getchar();
					return;
				}
				answer = mxmlFindElement(answer, tree, "text", NULL, NULL, MXML_DESCEND_FIRST);
				if(!answer) {
					perror("While parsing  no <text> tag inside <answer> found for naq");
					getchar();
					return;
				}
				strcpy(tempstr, answer->child->value.text.string);

				naq.ans = atof(tempstr);/*answer tag*/
				fwrite(&naq, sizeof(NAQ), 1, fp);/*Storing NAQ structure*/
				break;
			case _MTP:
				j = 0;
				for(answer = mxmlFindElement(node, tree, "subquestion", NULL, NULL, MXML_DESCEND_FIRST); answer != NULL; answer = mxmlGetNextSibling(answer)) {
					j++;
				}
				printf("There are %d many pairs\n", --j);
				node3 = mxmlFindElement(node2, tree, "no_of_pairs", NULL, NULL, MXML_DESCEND_FIRST);
				
				fwrite(&(j), sizeof(int), 1, fp);/*No of pairs tag*/
				
			
				for(answer = mxmlFindElement(node, tree, "subquestion", NULL, NULL, MXML_DESCEND_FIRST); answer != NULL; answer = mxmlGetNextSibling(answer)) {
					temp =  mxmlFindElement(answer, tree, "text", NULL, NULL, MXML_DESCEND_FIRST);/*ques tag*/
					if(!temp) {
						perror("While parsing  no <text> inside <subquestion> tag found");
						getchar();
						return;
					}
					strcpy(pairs.str1, temp->child->value.text.string);
					
					node =  mxmlFindElement(answer, tree, "answer", NULL, NULL, MXML_DESCEND_FIRST);/*ans tag*/
					if(!node) {
						perror("While parsing  no <answer> inside <subquestion> tag found");
						getchar();
						return;
					}
					strcpy(pairs.str2, node->child->child->value.text.string);
					fwrite(&pairs, sizeof(pair), 1, fp);
									
				}
				break;
						
		}
		
		
		
	}
	printf("\nDATA imported\n");
	getchar();
	getchar();
	fclose(fp);
	mxmlDelete(tree);
}
